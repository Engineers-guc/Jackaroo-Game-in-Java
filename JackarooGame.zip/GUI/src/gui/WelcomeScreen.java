package gui;
import javafx.geometry.Insets;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;
import javafx.stage.Screen;

public class WelcomeScreen extends BorderPane {
    
    private JackarooApp app;
    
    public WelcomeScreen(JackarooApp app) {
        this.app = app;
        setUpUI();
        setOpacity(1.0); // Ensure root starts fully opaque for fade transitions
    }
    
    private void setUpUI() {
        // Make components size responsively with screen dimensions
        double screenWidth = Screen.getPrimary().getBounds().getWidth();
        double screenHeight = Screen.getPrimary().getBounds().getHeight();
        
        // Set class for background image styling
        getStyleClass().add("welcome-screen");
        
        // Create text shadow effect for better visibility on image background
        DropShadow textShadow = new DropShadow();
        textShadow.setColor(Color.rgb(0, 0, 0, 0.7));
        textShadow.setRadius(5);
        textShadow.setSpread(0.2);
        
        // Title and welcome message with shadow
        Text title = new Text("Welcome to Jackaroo");
        title.setFont(Font.font("Arial", FontWeight.BOLD, screenHeight * 0.06)); // Larger font size
        title.setFill(Color.WHITE);
        title.setEffect(textShadow);
        
        Text subtitle = new Text("The Ultimate Board Game Experience");
        subtitle.setFont(Font.font("Arial", FontWeight.NORMAL, screenHeight * 0.03));
        subtitle.setFill(Color.WHITE);
        subtitle.setEffect(textShadow);
        
        // Player name input field with responsive sizing and styling
        Label nameLabel = new Label("Enter Your Name:");
        nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, screenHeight * 0.02));
        nameLabel.setTextFill(Color.WHITE);
        nameLabel.setEffect(textShadow);
        
        TextField nameField = new TextField();
        nameField.setPromptText("Your name");
        nameField.setPrefWidth(screenWidth * 0.2);
        nameField.setMaxWidth(300);
        nameField.setFont(Font.font("Arial", FontWeight.NORMAL, screenHeight * 0.018));
        nameField.getStyleClass().add("name-field");
        
        // Start game button with responsive styling
        Button startButton = new Button("Start Game");
        startButton.getStyleClass().add("welcome-button");
        startButton.setPrefWidth(screenWidth * 0.2);
        startButton.setPrefHeight(screenHeight * 0.06);
        startButton.setFont(Font.font("Arial", FontWeight.BOLD, screenHeight * 0.022));
        startButton.setOnAction(e -> {
            String playerName = nameField.getText().trim();
            if (playerName.isEmpty()) {
                playerName = "Player 1";
            }
            app.startGame(playerName);
        });

        // Game Story button
        Button storyButton = new Button("Game Story");
        storyButton.getStyleClass().add("welcome-button");
        storyButton.setPrefWidth(screenWidth * 0.2);
        storyButton.setPrefHeight(screenHeight * 0.06);
        storyButton.setFont(Font.font("Arial", FontWeight.BOLD, screenHeight * 0.022));
        storyButton.setOnAction(e -> app.showGameStoryScreen());
        
        // Arrange components with responsive spacing
        VBox headerBox = new VBox(screenHeight * 0.02, title, subtitle);
        headerBox.setAlignment(Pos.CENTER);
        headerBox.getStyleClass().add("welcome-header");
        headerBox.setPadding(new Insets(screenHeight * 0.1, 0, 0, 0)); // Add top padding
        
        HBox inputBox = new HBox(screenWidth * 0.02, nameLabel, nameField);
        inputBox.setAlignment(Pos.CENTER);
        inputBox.getStyleClass().add("input-box");
        
        // Remove game description entirely
        VBox contentBox = new VBox();
        contentBox.getChildren().setAll(inputBox, startButton, storyButton);
        contentBox.setAlignment(Pos.CENTER);
        contentBox.setMaxHeight(screenWidth/4);
        contentBox.getStyleClass().add("welcome-content");
        contentBox.setMaxWidth(screenWidth * 0.385); // 10% wider than previous 0.35
        contentBox.setStyle("-fx-background-color: rgba(0,0,0,0.55); -fx-background-radius: 18; -fx-padding: 9 32 9 32;"); // vertical padding halved

        setTop(headerBox);
        setCenter(contentBox);
    }
} 