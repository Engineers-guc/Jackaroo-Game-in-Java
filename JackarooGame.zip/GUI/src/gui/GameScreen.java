package gui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collections;

import engine.Game;
import engine.board.Board;
import engine.board.Cell;
import exception.ActionException;
import exception.GameException;
import exception.InvalidCardException;
import exception.InvalidMarbleException;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Region;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import model.Colour;
import model.card.Card;
import model.player.Marble;
import model.player.Player;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.stage.Screen;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.RowConstraints;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Priority;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.control.TextField;
import javafx.animation.PauseTransition;
import javafx.util.Duration;

public class GameScreen extends BorderPane {
    
    private Game game;
    private JackarooApp app;
    private Board board;
    
    // Add static MediaPlayer for background music
    private static MediaPlayer backgroundMusicPlayer;
    
    private ArrayList<PlayerPanel> playerPanels = new ArrayList<>();
    public BoardView boardView;
    private Map<Cell, CellView> cellViews = new HashMap<>();
    
    private TextArea messageArea;
    private Button playButton;
    private CardView selectedCardView;
    private ArrayList<MarbleView> selectedMarbleViews = new ArrayList<>();
    
    private Label turnLabel;
    private VBox boardAndFirePitContainer; // Container for board and fire pit
    
    private CardView firePitCardView;
    
    private Map<Marble, Boolean> marbleInSafeZone = new HashMap<>();

    public GameScreen(Game game, JackarooApp app) {
        this.game = game;
        this.app = app;
        this.board = game.getBoard();
        setStyle("-fx-background-color: #2d1b0e;"); // brownish-black background
        
        // Set this GameScreen on the board to enable event notifications
        if (board instanceof engine.board.Board) {
            ((engine.board.Board) board).setGameScreen(this);
        }
        
        setupUI();
        updateUI();
        setupKeyHandlers();
        setFocusTraversable(true);
        
        // Start background music when game screen is created
        startBackgroundMusic();
    }
    
    private void setupUI() {
        // Initialize container for board and fire pit
        boardAndFirePitContainer = new VBox();
        boardAndFirePitContainer.setAlignment(Pos.CENTER);
        
        // Setup the board first to get its size
        setupBoardView();
        
        // Set up player panels first but don't add them to layout yet
        setupPlayerPanels();
        
        // Create an overlay for player panels that will be positioned on the board
        StackPane boardWithPanelsOverlay = new StackPane();
        
        // Add the board view first (underneath)
        boardWithPanelsOverlay.getChildren().add(boardView);
        
        // Create overlay for player panels that will sit on top of the board
        AnchorPane playerOverlay = new AnchorPane();
        
        // Position player panels on the board in the white spaces
        positionPlayerPanelsOnBoard(playerOverlay);
        
        // NOTE: Turn label is now moved to game controls, so removing it from here
        // We'll keep the reference but create it later
        turnLabel = new Label();
        
        boardWithPanelsOverlay.getChildren().add(playerOverlay);
        
        // Place the board with overlay in the center
        setCenter(boardWithPanelsOverlay);
        
        // Setup game controls at the bottom of the screen
        setupGameControls();
        
        // Add initial message
        addMessage("Welcome to Jackaroo! Game started with " + game.getPlayers().size() + " players.");
        updateUI();
        
        getStyleClass().add("fullscreen-game");
        this.setFocusTraversable(true);
        this.requestFocus();
        this.setOnMouseClicked(e -> this.requestFocus());
    }
    
    private void setupBoardView() {
        // Create board view
        boardView = new BoardView(board, this);
        // Add board view to the new container
        boardAndFirePitContainer.getChildren().add(boardView);
        
        // Store references to cell views for easy access
        cellViews = boardView.getCellViewMap();
    }
    
    private void setupPlayerPanels() {
        // Create player panels but do not add them to the board overlay
        // This will happen in positionPlayerPanelsOnBoard
        
        // Get all players
        ArrayList<Player> allPlayers = game.getPlayers();
        int playerCount = allPlayers.size();
        
        // Create player panels with uniform size for all
        for (int i = 0; i < playerCount; i++) {
            Player player = allPlayers.get(i);
            PlayerPanel playerPanel = new PlayerPanel(player, this, game);
            playerPanels.add(playerPanel);
            
            // Set the first player as active by default
            if (i == 0) {
                playerPanel.setActive(true);
            }
            // All panels have the same size
            playerPanel.setPrefSize(120, 120);
            playerPanel.setMaxSize(120, 120);
        }
    }
    
    private void positionPlayerPanelsOnBoard(AnchorPane playerOverlay) {
        double boardWidth = boardView.getWidth();
        double boardHeight = boardView.getHeight();
        if (boardWidth <= 0 || boardHeight <= 0) {
            boardWidth = boardView.getPrefWidth();
            boardHeight = boardView.getPrefHeight();
        }

        // Define offset values to move panels more towards center
        double horizontalOffset = boardWidth * 0.08;  // 8% of board width for left panels
        double rightHorizontalOffset = boardWidth * 0.04;  // 4% of board width for right panels (closer to edge)
        double verticalOffset = boardHeight * 0.08;   // 8% of board height

        for (int i = 0; i < playerPanels.size() && i < 4; i++) {
            PlayerPanel panel = playerPanels.get(i);
            Colour playerColor = panel.getPlayer().getColour();
            playerOverlay.getChildren().add(panel);
            switch (playerColor) {
                case BLUE: // Top-left
                    AnchorPane.setLeftAnchor(panel, horizontalOffset);
                    AnchorPane.setTopAnchor(panel, verticalOffset);
                    break;
                case RED: // Top-right
                    AnchorPane.setRightAnchor(panel, rightHorizontalOffset);
                    AnchorPane.setTopAnchor(panel, verticalOffset);
                    break;
                case YELLOW: // Bottom-right
                    AnchorPane.setRightAnchor(panel, rightHorizontalOffset);
                    AnchorPane.setBottomAnchor(panel, verticalOffset);
                    break;
                case GREEN: // Bottom-left
                    AnchorPane.setLeftAnchor(panel, horizontalOffset);
                    AnchorPane.setBottomAnchor(panel, verticalOffset);
                    break;
                default:
                    break;
            }
        }
    }
    
    private int getPositionIndexForColor(Colour colour) {
        // Match colors to board positions
        switch (colour) {
            case BLUE: return 0;   // Top left
            case RED: return 1;    // Top right
            case YELLOW: return 2; // Bottom left
            case GREEN: return 3;  // Bottom right
            default: return 0;
        }
    }
    
    private void setupGameControls() {
        // Responsive sizing
        double controlsHeight = 80;

        // Root HBox for all controls
        HBox rootControls = new HBox(15);
        rootControls.setAlignment(Pos.CENTER_LEFT);
        rootControls.setPadding(new Insets(10, 20, 10, 20));
        rootControls.setStyle("-fx-background-color: #222;");

        // Left: GridPane for marble selection
        GridPane marbleGrid = new GridPane();
        marbleGrid.setHgap(8);
        marbleGrid.setVgap(8);
        marbleGrid.setPadding(new Insets(5));
        marbleGrid.setStyle("-fx-background-color: #333; -fx-border-color: #555; -fx-border-width: 1px; -fx-border-radius: 5px;");

        Label marbleLabel1 = new Label("Marble 1:");
        TextField marbleField1 = new TextField();
        marbleField1.setPromptText("Cell index");
        Button select1 = new Button("Select 1");
        select1.setOnAction(e -> {
            try {
                int idx = Integer.parseInt(marbleField1.getText());
                selectMarbleByIndex(idx);
            } catch (NumberFormatException ex) {
                showErrorDialog("Invalid Input", "Enter a valid cell index");
            }
        });

        Label marbleLabel2 = new Label("Marble 2:");
        TextField marbleField2 = new TextField();
        marbleField2.setPromptText("Cell index");
        Button select2 = new Button("Select 2");
        select2.setOnAction(e -> {
            try {
                int idx = Integer.parseInt(marbleField2.getText());
                selectMarbleByIndex(idx);
            } catch (NumberFormatException ex) {
                showErrorDialog("Invalid Input", "Enter a valid cell index");
            }
        });

        Button clearBtn = new Button("Clear");
        clearBtn.setOnAction(e -> {
            clearMarbleSelections();
            marbleField1.clear();
            marbleField2.clear();
        });

        marbleGrid.add(marbleLabel1, 0, 0);
        marbleGrid.add(marbleField1, 1, 0);
        marbleGrid.add(select1, 2, 0);
        marbleGrid.add(marbleLabel2, 0, 1);
        marbleGrid.add(marbleField2, 1, 1);
        marbleGrid.add(select2, 2, 1);
        marbleGrid.add(clearBtn, 1, 2);

        // Middle: VBox for turn label and buttons
        VBox buttonContainer = new VBox(10);
        buttonContainer.setAlignment(Pos.CENTER);
        
        // Add the turn label at the top of the button container
        turnLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        turnLabel.setAlignment(Pos.CENTER);
        turnLabel.setTextFill(Color.WHITE);
        turnLabel.setStyle("-fx-background-color: rgba(0,0,0,0.7); -fx-padding: 8px 15px; -fx-background-radius: 5px;");
        turnLabel.setMaxWidth(Double.MAX_VALUE);
        
        // HBox for buttons
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);

        playButton = new Button("Play");
        playButton.getStyleClass().add("game-button");
        playButton.setDisable(true);
        playButton.setOnAction(e -> handlePlayButton());
        
        Button rulesButton = new Button("Game Rules");
        rulesButton.getStyleClass().add("game-button");
        rulesButton.setOnAction(e -> showGameRules());

        Button endTurnButton = new Button("Skip Turn");
        endTurnButton.getStyleClass().add("game-button");
        endTurnButton.setOnAction(e -> handleEndTurn());
        
        Button deselectButton = new Button("Deselect");
        deselectButton.getStyleClass().add("game-button");
        deselectButton.setOnAction(e -> handleDeselectButton());
        
        buttonBox.getChildren().addAll(playButton, deselectButton, rulesButton, endTurnButton);
        
        // Add turn label and buttons to the container
        buttonContainer.getChildren().addAll(turnLabel, buttonBox);

        // Message area for game messages
        messageArea = new TextArea();
        messageArea.setEditable(false);
        messageArea.setPrefWidth(350);
        messageArea.setPrefHeight(80);
        messageArea.setWrapText(true);
        messageArea.setStyle("-fx-font-size: 13px; -fx-control-inner-background: #181818; -fx-text-fill: white;");
        
        // Right: Add a separate fire pit display here
        VBox firePitBox = new VBox(5);
        firePitBox.setAlignment(Pos.CENTER);
        firePitBox.setPadding(new Insets(5));
        firePitBox.setStyle("-fx-background-color: #5e3b1c; -fx-border-color: #8B4513; -fx-border-width: 2px; -fx-border-radius: 5px;");
        firePitBox.setPrefWidth(180);  // Increased width
        firePitBox.setPrefHeight(250); // Increased height
        firePitBox.setId("fire-pit-box"); // Add an ID for easier lookup
        
        Label firePitLabel = new Label("FIRE PIT");
        firePitLabel.setTextFill(Color.WHITE);
        firePitLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        
        // Create a card view that will be updated later
        CardView firePitCardView = new CardView(null);
        firePitCardView.setPrefSize(150, 200); // Increased card size
        
        firePitBox.getChildren().addAll(firePitLabel, firePitCardView);
        
        // Store a reference to this card view so we can update it
        this.firePitCardView = firePitCardView;
        
        // Add to the root HBox
        rootControls.getChildren().addAll(marbleGrid, buttonContainer, messageArea, firePitBox);
        
        // Make the last two elements grow to fill space
        HBox.setHgrow(messageArea, Priority.ALWAYS);
        HBox.setHgrow(firePitBox, Priority.NEVER);

        // Set at bottom
        setBottom(rootControls);
    }
    
    private void updateUI() {
        int currentPlayerIndex = game.getCurrentPlayerIndex();
        int nextPlayerIndex = game.getNextPlayerIndex();
        
        // Check if this is the start of a new round (all players have fresh hands)
        boolean isNewRound = true;
        for (Player player : game.getPlayers()) {
            if (player.getHand().size() != 4) {
                isNewRound = false;
                break;
            }
        }
        if (isNewRound && currentPlayerIndex == 0) {
            playShuffleSound();
        }
        
        for (int i = 0; i < playerPanels.size(); i++) {
            playerPanels.get(i).setActive(i == currentPlayerIndex);
            playerPanels.get(i).updateCards();
        }
        updateBoardCells();
        
        // Always refresh the fire pit when updating UI
        refreshFirePit();
        
        Player currentPlayer = game.getPlayers().get(currentPlayerIndex);
        Player nextPlayer = game.getPlayers().get(nextPlayerIndex);
        String turnMsg = "Current turn: " + currentPlayer.getName() + " (" + currentPlayer.getColour() + ") | Next: " + nextPlayer.getName() + " (" + nextPlayer.getColour() + ")";
        if (turnLabel != null) turnLabel.setText(turnMsg);
    }
    
    private void checkAndPlaySafeZoneSound(Cell cell) {
        if (cell.getMarble() != null && 
            cell.getCellType() != null && 
            cell.getCellType().toString().equals("SAFE")) {
            
            Marble marble = cell.getMarble();
            Boolean wasInSafeZone = marbleInSafeZone.get(marble);
            
            // If the marble wasn't in a safe zone before, play the sound
            if (wasInSafeZone == null || !wasInSafeZone) {
                playSafeZoneSound();
                marbleInSafeZone.put(marble, true);
            }
        } else if (cell.getMarble() != null) {
            // If marble is not in safe zone, mark it as not in safe zone
            marbleInSafeZone.put(cell.getMarble(), false);
        }
    }

    private void updateBoardCells() {
        // Update the board view with current game state
        System.out.println("[DEBUG] GameScreen.updateBoardCells: Updating board cells");
        boardView.update();
        
        // Force a complete refresh of all cell views
        for (Map.Entry<Cell, CellView> entry : cellViews.entrySet()) {
            Cell cell = entry.getKey();
            CellView cellView = entry.getValue();
            
            // Debug: print cell with marble
            if (cell.getMarble() != null) {
                System.out.println("[DEBUG] Cell has marble: " + cell + " → " + cell.getMarble());
                
                // Check for safe zone entry
                checkAndPlaySafeZoneSound(cell);
            }
            
            // Force redraw the marble display
            cellView.updateMarbleDisplay();
        }
    }
    
    public void handleCardSelection(CardView cardView) {
        if (selectedCardView != null) {
            selectedCardView.setSelected(false);
        }
        selectedCardView = cardView;
        cardView.setSelected(true);
        clearMarbleSelections();
        playButton.setDisable(false);
        
        // Get the card from the CardView
        Card viewCard = cardView.getCard();
        try {
            // Get the current player
            Player currentPlayer = game.getPlayers().get(game.getCurrentPlayerIndex());
            
            // Find the actual card object from the player's hand by name match
            Card cardInHand = null;
            for (Card card : currentPlayer.getHand()) {
                if (card.getName().equals(viewCard.getName())) {
                    cardInHand = card;
                    break;
                }
            }
            
            // If we found a matching card, select it in the game
            if (cardInHand != null) {
                // Select the card in the game engine - using the reference from the player's hand
                game.selectCard(cardInHand);
                
                highlightActionableMarbles();
                String cardName = cardInHand.getName();
                String cardDesc = cardInHand.getDescription();
                String rankStr = "?";
                
                // Add a hint for Seven cards
                boolean isSeven = cardName.contains("SEVEN") || 
                                 (cardInHand instanceof model.card.standard.Seven);
                if (isSeven) {
                    addMessage("HINT: Select two marbles to split the seven steps between them.");
                }
                
                // Try to get rank from CSV for standard cards
                if (cardInHand.getClass().getSimpleName().equals("Standard")) {
                String suit = "";
                if (cardName.contains("HEART")) suit = "HEART";
                else if (cardName.contains("DIAMOND")) suit = "DIAMOND";
                else if (cardName.contains("SPADE")) suit = "SPADE";
                else if (cardName.contains("CLUB")) suit = "CLUB";
                    
                // Robust extraction of value
                String[] parts = cardName.split("_");
                String value = parts[parts.length - 1];
                String csvName = value;
                if (csvName.equalsIgnoreCase("ACE")) csvName = "Ace";
                else if (csvName.equalsIgnoreCase("KING")) csvName = "King";
                else if (csvName.equalsIgnoreCase("QUEEN")) csvName = "Queen";
                else if (csvName.equalsIgnoreCase("JACK")) csvName = "Jack";
                else if (csvName.matches("\\d+")) csvName = String.valueOf(Integer.parseInt(csvName));
                    
                try (BufferedReader br = new BufferedReader(new FileReader("GUI/Cards.csv"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        String[] csvParts = line.split(",");
                        if (csvParts.length >= 6 && csvParts[2].equalsIgnoreCase(csvName) && csvParts[5].equalsIgnoreCase(suit)) {
                            rankStr = csvParts[4];
                            break;
                        }
                    }
                } catch (IOException e) {
                    rankStr = "?";
                }
            }
                
            addMessage("Selected card: " + cardName + (rankStr.equals("?") ? "" : " (Rank: " + rankStr + ")") + " - " + cardDesc);
            } else {
                showErrorDialog("Card Selection Error", "Card not found in player's hand");
                // Reset selection if card not found
                selectedCardView = null;
                cardView.setSelected(false);
                playButton.setDisable(true);
            }
        } catch (InvalidCardException e) {
            showErrorDialog("Card Selection Error", e.getMessage());
            // Reset selection if there was an error
            selectedCardView = null;
            cardView.setSelected(false);
            playButton.setDisable(true);
        } catch (Exception e) {
            showErrorDialog("Card Selection Error", "Error selecting card: " + e.getMessage());
            // Reset selection if there was an error
            selectedCardView = null;
            cardView.setSelected(false);
            playButton.setDisable(true);
        }
    }
    
    private void highlightActionableMarbles() {
        clearHighlights();
        if (selectedCardView == null) return;
        String cardName = selectedCardView.getCard().getName();
        ArrayList<MarbleView> allMarbleViews = getAllMarbleViews();
        if (cardName.contains("JACK")) {
            // For Jack: highlight player's marbles and opponent marbles
            Colour playerColour = game.getActivePlayerColour();
            for (MarbleView mv : allMarbleViews) {
                if (isInBasePosition(mv.getMarble())) continue;
                mv.setHighlighted(true);
            }
        } else if (cardName.contains("FIVE")) {
            // For Five: highlight all marbles
            for (MarbleView mv : allMarbleViews) {
                mv.setHighlighted(true);
            }
        } else if (cardName.contains("SEVEN")) {
            // For Seven: highlight player's marbles for selection
            Colour playerColour = game.getActivePlayerColour();
            for (MarbleView mv : allMarbleViews) {
                if (mv.getMarble().getColour() == playerColour) {
                    mv.setHighlighted(true);
                }
            }
        } else if (cardName.contains("BURNER")) {
            Colour playerColour = game.getActivePlayerColour();
            for (MarbleView mv : allMarbleViews) {
                if (mv.getMarble().getColour() != playerColour && !isInBasePosition(mv.getMarble())) {
                    mv.setHighlighted(true);
                }
            }
        } else if (cardName.contains("SAVER")) {
            Colour playerColour = game.getActivePlayerColour();
            for (MarbleView mv : allMarbleViews) {
                if (mv.getMarble().getColour() == playerColour && !isInSafeZone(mv.getMarble())) {
                    mv.setHighlighted(true);
                }
            }
        } else {
            Colour playerColour = game.getActivePlayerColour();
            for (MarbleView mv : allMarbleViews) {
                if (mv.getMarble().getColour() == playerColour) {
                    mv.setHighlighted(true);
                }
            }
        }
    }
    
    private ArrayList<MarbleView> getAllMarbleViews() {
        ArrayList<MarbleView> marbles = new ArrayList<>();
        
        // Get all marbles from all cells
        for (CellView cellView : cellViews.values()) {
            MarbleView mv = cellView.getMarbleView();
            if (mv != null) {
                marbles.add(mv);
            }
        }
        
        return marbles;
    }
    
    public boolean isInBasePosition(Marble marble) {
        // Check if the marble is in its base position
        // This is a simplified check - you might need to adjust based on your board implementation
        for (CellView cellView : cellViews.values()) {
            if (cellView.getCell().getCellType() != null && 
                cellView.getCell().getCellType().toString().equals("BASE") && 
                cellView.getMarbleView() != null &&
                cellView.getMarbleView().getMarble() == marble) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isInSafeZone(Marble marble) {
        // Check if the marble is in a safe zone
        for (CellView cellView : cellViews.values()) {
            if (cellView.getCell().getCellType() != null && 
                cellView.getCell().getCellType().toString().equals("SAFE") && 
                cellView.getMarbleView() != null &&
                cellView.getMarbleView().getMarble() == marble) {
                return true;
            }
        }
        return false;
    }
    
    private void clearHighlights() {
        // Clear all marble highlights
        for (CellView cellView : cellViews.values()) {
            MarbleView mv = cellView.getMarbleView();
            if (mv != null) {
                mv.setHighlighted(false);
            }
        }
    }
    
    public void handleMarbleSelection(MarbleView marbleView) {
        System.out.println("[DEBUG] GameScreen.handleMarbleSelection: " + marbleView.getMarble().getColour());
        
        // SIMPLIFIED: Let the MarbleView toggle its own selection state
        // We just need to maintain our list and game state
        
        // If marble is now selected (after toggle in MarbleView)
        if (marbleView.isSelected()) {
            // Add to our selection list if not already there
            if (!selectedMarbleViews.contains(marbleView)) {
                selectedMarbleViews.add(marbleView);
                System.out.println("[DEBUG] Added marble to selection: " + selectedMarbleViews.size());
            }
            
            try {
                // Update game engine state
                game.selectMarble(marbleView.getMarble());
                addMessage("Selected marble: " + marbleView.getMarble().getColour());
            } catch (Exception e) {
                showErrorDialog("Selection Error", e.getMessage());
                // If selection failed, revert visual state
                marbleView.setSelected(false);
                selectedMarbleViews.remove(marbleView);
                    return;
                }
        } else {
            // Remove from our selection list
            selectedMarbleViews.remove(marbleView);
            System.out.println("[DEBUG] Removed marble from selection: " + selectedMarbleViews.size());
            
            try {
                // Update game engine - need to deselect all and rebuild
                game.deselectAll();
                
                // Re-select the card if we have one
                if (selectedCardView != null) {
                    game.selectCard(selectedCardView.getCard());
                }
                
                // Re-select any marbles still in our list
                for (MarbleView mv : selectedMarbleViews) {
                        game.selectMarble(mv.getMarble());
                    }
            } catch (Exception e) {
                showErrorDialog("Selection Error", e.getMessage());
            }
        }
        
        // Always enable the play button if we have a card selected
        if (selectedCardView != null) {
            playButton.setDisable(false);
        }
    }
    
    private void handlePlayButton() {
        try {
        if (selectedCardView == null) {
                showErrorDialog("No Card Selected", "You must select a card first.");
            return;
        }
        
            // Get the card from the selected card view
            Card viewCard = selectedCardView.getCard();
            if (viewCard == null) {
                showErrorDialog("Error", "Selected card is not valid.");
                return;
            }
            
            // Get the current player
            Player currentPlayer = game.getPlayers().get(game.getCurrentPlayerIndex());
            
            // Find the actual card object from the player's hand by name match
            Card cardInHand = null;
            for (Card card : currentPlayer.getHand()) {
                if (card.getName().equals(viewCard.getName())) {
                    cardInHand = card;
                    break;
                }
            }
            
            if (cardInHand == null) {
                showErrorDialog("Card Not Found", "The selected card was not found in your hand.");
                return;
            }
            
            try {
                // Select the card in the game engine
                game.selectCard(cardInHand);
                
                boolean isCardMarker = false;
                // Let's take action based on what's selected
                if (selectedMarbleViews.size() >= 1) {
                    // Convert views to actual marbles
                    ArrayList<Marble> selectedMarbles = new ArrayList<>();
                    for (MarbleView mv : selectedMarbleViews) {
                        Marble marble = mv.getMarble();
                        if (marble != null) {
                            isCardMarker = true;
                            selectedMarbles.add(marble);
                        }
                    }
                    
                    if (!selectedMarbles.isEmpty()) {
                        for (Marble marble : selectedMarbles) {
                            game.selectMarble(marble);
                        }
                        
                        // Check if this is a Seven card with two marbles - handle split distance
                        boolean isSeven = cardInHand.getName().contains("SEVEN") || 
                                         (cardInHand instanceof model.card.standard.Seven);
                        
                        if (isSeven && selectedMarbles.size() == 2) {
                            // Show dialog to choose split distance
                            SplitDistanceDialog dialog = new SplitDistanceDialog(getScene().getWindow());
                            int splitDistance = dialog.showAndWait();
                            
                            // If dialog was cancelled, abort the play
                            if (splitDistance == -1) {
                                addMessage("Split distance selection cancelled.");
                                return;
                            }
                            
                            try {
                                // Set the split distance in the game
                                game.editSplitDistance(splitDistance);
                                addMessage("Split distance set to " + splitDistance + " for first marble and " 
                                         + (7 - splitDistance) + " for second marble.");
                            } catch (Exception e) {
                                showErrorDialog("Split Distance Error", "Invalid split distance: " + e.getMessage());
                                return;
                            }
                        }
                        
                        // If we have cards and marbles, let's try to play the turn
                        try {
                            game.playPlayerTurn();
                            
                            // End the turn after playing
                            handleEndTurn();
                        } catch (Exception e) {
                            // Show error but don't end turn on failure
                            showErrorDialog("Cannot Play", "Unable to play this combination: " + e.getMessage());
                            
                            // Don't end turn on failure - disselect all to allow user to try again
                            game.deselectAll();
                            resetGameUI();
                        }
                    }
                }
                
                // Special case: No marbles selected might be valid for some cards
                if (!isCardMarker) {
                    try {
                        game.playPlayerTurn();
                        
                        // End the turn after playing
                        handleEndTurn();
                    } catch (Exception e) {
                        showErrorDialog("Cannot Play", "Unable to play this card without selecting marbles: " + e.getMessage());
                        
                        // Don't end turn on failure
                        game.deselectAll();
                        resetGameUI();
                    }
                }
                
            } catch (Exception e) {
                showErrorDialog("Error", "Failed to select card: " + e.getMessage());
            }
            
        } catch (Exception e) {
            showErrorDialog("Play Error", "An error occurred while playing: " + e.getMessage());
        }
    }
    
    private void handleEndTurn() {
        try {
            // Need to ensure a card is selected before ending the turn
            Player currentPlayer = game.getPlayers().get(game.getCurrentPlayerIndex());
            
            // Check if the current player has no cards left - skip directly to next player
            if (currentPlayer.getHand().isEmpty()) {
                addMessage(currentPlayer.getName() + " has no cards left. Turn skipped.");
                // Use skipToNextPlayer instead of endPlayerTurn to ensure proper turn transition
                game.skipToNextPlayer();
                
                // Update UI manually since we're not calling game.endPlayerTurn()
                resetGameUI();
                updateUI();
                
                // Update player panels and start CPU turns if needed
        for (PlayerPanel panel : playerPanels) {
                    panel.setActive(game.isCurrentPlayerTurn(panel.getPlayer()));
                    panel.updateCards(); // Update card display for all players
                }
                
                // Start CPU turns if needed
                if (!isHumanPlayerTurn()) {
                    handleCPUTurns();
                }
                
                return;
            }
            
            Card selectedCard = currentPlayer.getSelectedCard();
            if (selectedCard == null) {
                showErrorDialog("No Card Selected", "You must select a card before ending your turn.");
                return;
            }
            
            // Create a strong copy of the card information for display
            final String cardName = selectedCard.getName();
            final String cardClass = selectedCard.getClass().getSimpleName();
            final String playerName = currentPlayer.getName();
            
            // End the turn and move to next player
            game.endPlayerTurn();
            
            // Add a message about which card was played
            addMessage(playerName + " played " + cardName);
            
            // Use a delayed update to ensure the firepit is properly updated with the played card
            Platform.runLater(() -> {
                // First try to get the card from the firepit directly
                Card firePitCard = null;
                if (!game.getFirePit().isEmpty()) {
                    firePitCard = game.getFirePit().get(game.getFirePit().size() - 1);
                    if (firePitCard != null && firePitCard.getName().equals(cardName)) {
                        // We found a matching card, use it for display
                        updateFirePitCard(firePitCard);
                        System.out.println("[DEBUG] Firepit updated with direct reference: " + firePitCard.getName());
                    } else {
                        // The name doesn't match, just do a general refresh
                        refreshFirePit();
                        System.out.println("[DEBUG] Firepit general refresh due to name mismatch");
                    }
                } else {
                    // Firepit is empty (strange), just do a general refresh
                    refreshFirePit();
                    System.out.println("[DEBUG] Firepit general refresh due to empty firepit");
                }
            });
            
            // Reset the game UI (clear selections, etc.)
            resetGameUI();
            
            // Update the game state (board, etc.)
            updateUI();
            
            // Update player panels
            for (PlayerPanel panel : playerPanels) {
                panel.setActive(game.isCurrentPlayerTurn(panel.getPlayer()));
                panel.updateCards(); // Update card display for all players
                panel.updateMarbleCount(); // Make sure the marble count is accurate
            }
            
            // Check for a winner
            Colour winnerColour = game.checkWin();
            if (winnerColour != null) {
                handleWin(winnerColour);
                return;
            }
            
            // --- START MODIFICATION: Add delay before next turn ---
            PauseTransition delay = new PauseTransition(Duration.seconds(2));
            delay.setOnFinished(event -> {
                // If it's a CPU's turn, handle that automatically
                if (!isHumanPlayerTurn()) {
                    handleCPUTurns();
                } else {
                    // If it's another human player's turn (in a future multiplayer setup)
                    // or back to the current human player after CPUs, just ensure UI is current.
                    // For now, this else branch primarily serves the single human player scenario.
                    updateUI(); // Ensure UI is updated for the next human turn.
                }
            });
            delay.play();
            // --- END MODIFICATION ---

        } catch (Exception e) {
            showErrorDialog("End Turn Error", "An error occurred when ending the turn: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void handleCPUTurns() {
        // Start the CPU turn loop with delay
        handleNextCPUTurn();
    }

    // Helper for CPU turns with delay and message
    private void handleNextCPUTurn() {
        if (isHumanPlayerTurn()) {
            // If it has become a human player's turn (e.g. after all CPUs played),
            // update the UI and stop further CPU turn processing.
            updateUI();
            return;
        }
        try {
            Player cpuPlayer = game.getPlayers().get(game.getCurrentPlayerIndex());
            String cpuName = cpuPlayer.getName();
            
            // Check if CPU player has no cards - automatically skip turn
            if (cpuPlayer.getHand().isEmpty()) {
                addMessage(cpuName + " has no cards left. Turn skipped.");
                game.skipToNextPlayer();
                refreshFirePit();
                updateUI();
                
                PauseTransition delay = new PauseTransition(Duration.seconds(2)); // Standard 2s delay
                delay.setOnFinished(e -> handleNextCPUTurn());
                delay.play();
                return;
            }
            
            Card cpuCard = cpuPlayer.getHand().isEmpty() ? null : cpuPlayer.getHand().get(0);
            String cardName = (cpuCard != null) ? cpuCard.getName() : "(no card)";
            
            // Check if CPU is trying to use MarbleSaver with all marbles in home zone
            if (cpuCard != null && 
                (cardName.toUpperCase().contains("SAVER") || 
                 cardName.toUpperCase().contains("MARBLE SAVER") || 
                 cardName.toUpperCase().contains("MARBLESAVER"))) {
                if (cpuPlayer.getMarbles().size() == 4) {
                    addMessage(cpuName + " tried to use " + cardName + " but has all marbles in home zone. Turn skipped.");
                    game.selectCard(cpuCard);
                    game.endPlayerTurn();
                    refreshFirePit();
                    updateUI();
                    PauseTransition delay = new PauseTransition(Duration.seconds(2)); // Standard 2s delay
                    delay.setOnFinished(e -> handleNextCPUTurn());
                    delay.play();
                    return;
                }
            }
            
            // Check if CPU is trying to use MarbleBurner but there are no valid targets
            if (cpuCard != null && 
                (cardName.toUpperCase().contains("BURNER") || 
                 cardName.toUpperCase().contains("MARBLE BURNER") || 
                 cardName.toUpperCase().contains("MARBLEBURNER"))) {
                boolean hasValidTarget = false;
                for (CellView cellView : cellViews.values()) {
                    MarbleView mv = cellView.getMarbleView();
                    if (mv != null) {
                        Marble marble = mv.getMarble();
                        if (marble.getColour() != cpuPlayer.getColour() && !isInBasePosition(marble)) {
                            hasValidTarget = true;
                            break;
                        }
                    }
                }
                if (!hasValidTarget) {
                    addMessage(cpuName + " tried to use " + cardName + " but there are no opponent marbles on the track. Turn skipped.");
                    game.selectCard(cpuCard);
                    game.endPlayerTurn();
                    refreshFirePit();
                    updateUI();
                    PauseTransition delay = new PauseTransition(Duration.seconds(2)); // Standard 2s delay
                    delay.setOnFinished(e -> handleNextCPUTurn());
                    delay.play();
                    return;
                }
            }
            
            addMessage(cpuName + " is thinking...");
            
            PauseTransition thinkingTimeout = new PauseTransition(Duration.seconds(7));
            thinkingTimeout.setOnFinished(e -> {
                if (!isHumanPlayerTurn() && cpuPlayer == game.getPlayers().get(game.getCurrentPlayerIndex())) {
                    try {
                        addMessage(cpuName + " is taking too long. Turn skipped.");
                        if (!cpuPlayer.getHand().isEmpty()) {
                            Collections.shuffle(cpuPlayer.getHand());
                            Card randCard = cpuPlayer.getHand().get(0);
                            game.selectCard(randCard);
                            addMessage(cpuName + " discarded: " + randCard.getName());
                        }
                        game.endPlayerTurn();
                        refreshFirePit();
        resetGameUI();
        updateUI();
                        PauseTransition delay = new PauseTransition(Duration.seconds(2)); // Standard 2s delay
                        delay.setOnFinished(event -> handleNextCPUTurn());
                        delay.play();
                    } catch (Exception ex) {
                        System.err.println("Error during CPU timeout: " + ex.getMessage());
                        ex.printStackTrace();
                    }
                }
            });
            thinkingTimeout.play();
            
            try {
                // Store the card reference before playing the turn
                Card cpuPlayingCard = cpuCard;
                final String cpuCardName = cardName;
                
                // If CPU is playing a Seven card with two marbles, set a random split distance
                if (cpuCard != null && (cpuCard.getName().contains("SEVEN") || cpuCard instanceof model.card.standard.Seven)) {
                    // Check how many marbles are selected (this happens internally in the CPU class)
                    try {
                        // Set a random split distance between 1 and 6
                        int cpuSplitDistance = 1 + (int)(Math.random() * 6);
                        game.editSplitDistance(cpuSplitDistance);
                        addMessage(cpuName + " split distance: " + cpuSplitDistance + " and " + (7-cpuSplitDistance));
                    } catch (Exception e) {
                        System.err.println("Error setting CPU split distance: " + e.getMessage());
                    }
                }
                
                game.playPlayerTurn();
                thinkingTimeout.stop();
                addMessage(cpuName + " played: " + cardName);
                
                // End the turn (this will add the card to firepit in Game object)
                game.endPlayerTurn();
                
                // Use delayed update to ensure the firepit shows the correct card
                Platform.runLater(() -> {
                    // First try to get the card from the firepit directly
                    Card firePitCard = null;
                    if (!game.getFirePit().isEmpty()) {
                        firePitCard = game.getFirePit().get(game.getFirePit().size() - 1);
                        if (firePitCard != null) {
                            // We found the card, use it for display
                            updateFirePitCard(firePitCard);
                            System.out.println("[DEBUG] CPU Firepit updated with direct reference: " + firePitCard.getName());
                        } else {
                            // Fall back to our stored reference
                            if (cpuPlayingCard != null) {
                                updateFirePitCard(cpuPlayingCard);
                                System.out.println("[DEBUG] CPU Firepit updated with stored reference: " + cpuPlayingCard.getName());
                            } else {
                                // Last resort - just refresh
                                refreshFirePit();
                                System.out.println("[DEBUG] CPU Firepit general refresh - no specific card reference");
                            }
                        }
                    } else {
                        // Firepit is empty (strange), try with stored reference
                        if (cpuPlayingCard != null) {
                            updateFirePitCard(cpuPlayingCard);
                            System.out.println("[DEBUG] CPU Firepit updated with stored reference: " + cpuPlayingCard.getName());
                        } else {
                            // Last resort - just refresh
                            refreshFirePit();
                            System.out.println("[DEBUG] CPU Firepit general refresh - empty firepit");
                        }
                    }
                });
                
                // Update UI to reflect CPU's move
                updateUI();

                PauseTransition delay = new PauseTransition(Duration.seconds(2)); // Standard 2s delay after successful CPU play
                delay.setOnFinished(e -> handleNextCPUTurn());
                delay.play();

            } catch (GameException e) {
                thinkingTimeout.stop();
                System.err.println("CPU Error: " + e.getMessage());
                addMessage("CPU player error: " + e.getMessage());
                try {
                    if (!cpuPlayer.getHand().isEmpty()) {
                        Card randCard = cpuPlayer.getHand().get(0);
                        game.selectCard(randCard);
                    }
                game.endPlayerTurn();
                    refreshFirePit();
                    resetGameUI();
                updateUI();
                    PauseTransition delay = new PauseTransition(Duration.seconds(2)); // Standard 2s delay
                    delay.setOnFinished(event -> handleNextCPUTurn());
                    delay.play();
                } catch (Exception ex) {
                    System.err.println("Error during CPU error recovery: " + ex.getMessage());
                }
            }
        } catch (Exception e) {
            System.err.println("Unexpected CPU turn error: " + e.getMessage());
            e.printStackTrace();
            try {
                game.skipToNextPlayer();
                updateUI();
                PauseTransition delay = new PauseTransition(Duration.seconds(2)); // Standard 2s delay
                delay.setOnFinished(event -> handleNextCPUTurn());
                delay.play();
            } catch (Exception ex) {
                System.err.println("Failed to recover from CPU turn error: " + ex.getMessage());
            }
        }
    }
    
    private boolean isHumanPlayerTurn() {
        Player currentPlayer = game.getPlayers().get(game.getCurrentPlayerIndex());
        // Check if this is not a CPU player (does not start with "CPU")
        return !currentPlayer.getName().startsWith("CPU");
    }
    
    private void handleWin(Colour winnerColour) {
        // Find the player with the winning color
        String winnerName = "";
        for (Player player : game.getPlayers()) {
            if (player.getColour() == winnerColour) {
                winnerName = player.getName();
                break;
            }
        }
        
        addMessage("Game Over! " + winnerName + " wins!");
        
        // Disable controls
        playButton.setDisable(true);
        
        // Stop background music before showing winner dialog
        stopBackgroundMusic();
        
        // Show winner dialog
        WinnerDialog winnerDialog = new WinnerDialog(getScene().getWindow(), winnerName, winnerColour, app);
        winnerDialog.show();
    }
    
    private void clearMarbleSelections() {
        for (MarbleView marbleView : selectedMarbleViews) {
            marbleView.setSelected(false);
        }
        selectedMarbleViews.clear();
        
        try {
            game.deselectAll();
        } catch (Exception e) {
            addMessage("Error: " + e.getMessage());
        }
    }
    
    public void addMessage(String message) {
        messageArea.appendText(message + "\n");
        messageArea.setScrollTop(Double.MAX_VALUE);
    }
    
    public boolean isCurrentPlayerTurn(Player player) {
        // Check if it's this player's turn
        return player == game.getPlayers().get(game.getCurrentPlayerIndex());
    }
    
    // Add a method to show game rules in a popup
    private void showGameRules() {
        Stage rulesStage = new Stage();
        rulesStage.initModality(Modality.APPLICATION_MODAL);
        rulesStage.initOwner(getScene().getWindow());
        rulesStage.setTitle("Jackaroo Game Rules");
        
        Text rulesTitle = new Text("Jackaroo Game Rules");
        rulesTitle.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        
        Text rulesText = new Text(
            "How to Play Jackaroo:\n\n" +
            "1. On your turn, select a card from your hand and play it to move your marbles.\n\n" +
            "2. Special cards have unique abilities:\n" +
            "   • Ace: Move a marble 1 space OR field a new marble from home.\n" +
            "   • King: Move a marble 13 spaces OR field a new marble from home.\n" +
            "   • Jack: Swap positions of your marble with an opponent's marble.\n" +
            "   • Seven: Split 7 steps between two of your marbles.\n" +
            "   • Burner (Wild): Destroy an opponent's marble (sending it back home).\n" +
            "   • Saver (Wild): Send one of your marbles to your safe zone.\n\n" +
            "3. To win, get all your marbles into your safe zone before the other players.\n\n" +
            "4. You can destroy opponent marbles by landing on them, sending them back home."
        );
        rulesText.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        rulesText.setWrappingWidth(500);
        
        Button closeButton = new Button("Close");
        closeButton.setPrefWidth(100);
        closeButton.setOnAction(e -> rulesStage.close());
        
        VBox rulesContent = new VBox(20, rulesTitle, rulesText, closeButton);
        rulesContent.setPadding(new Insets(30));
        rulesContent.setAlignment(Pos.TOP_CENTER);
        rulesContent.getStyleClass().add("game-rules-panel");
        
        ScrollPane scrollPane = new ScrollPane(rulesContent);
        scrollPane.setFitToWidth(true);
        
        Scene rulesScene = new Scene(scrollPane, 600, 500);
        rulesScene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());
        
        rulesStage.setScene(rulesScene);
        rulesStage.show();
    }
    
    // Add a method to display error dialogs
    private void showErrorDialog(String title, String message) {
        ErrorDialog.showError(getScene().getWindow(), title, message);
    }
    
    private void updatePlayerPanelPositions() {
        if (boardView == null || playerPanels.isEmpty()) {
            return;
        }
        
        // Get the AnchorPane that contains the player panels
        StackPane boardWithPanelsOverlay = (StackPane) getCenter();
        if (boardWithPanelsOverlay == null || boardWithPanelsOverlay.getChildren().size() < 2) {
            return;
        }
        
        AnchorPane playerOverlay = (AnchorPane) boardWithPanelsOverlay.getChildren().get(1);
        
        // Clear and re-add player panels with updated positions
        playerOverlay.getChildren().removeAll(playerPanels);
        
        // Reposition panels
        positionPlayerPanelsOnBoard(playerOverlay);
    }
    
    private void playFieldingSound() {
        try {
            javafx.scene.media.Media sound = new javafx.scene.media.Media(new java.io.File("C:\\Users\\LENOVO\\Downloads\\marblefield.mp3").toURI().toString());
            javafx.scene.media.MediaPlayer mediaPlayer = new javafx.scene.media.MediaPlayer(sound);
            mediaPlayer.play();
        } catch (Exception e) {
            System.err.println("Error playing fielding sound: " + e.getMessage());
        }
    }

    private void playShuffleSound() {
        try {
            javafx.scene.media.Media sound = new javafx.scene.media.Media(new java.io.File("C:\\Users\\LENOVO\\Downloads\\shuffle-cards-46455.mp3").toURI().toString());
            javafx.scene.media.MediaPlayer mediaPlayer = new javafx.scene.media.MediaPlayer(sound);
            mediaPlayer.play();
        } catch (Exception e) {
            System.err.println("Error playing shuffle sound: " + e.getMessage());
        }
    }

    private void playCardFlipSound() {
        try {
            javafx.scene.media.Media sound = new javafx.scene.media.Media(new java.io.File("C:\\Users\\LENOVO\\Downloads\\flipcard-91468.mp3").toURI().toString());
            javafx.scene.media.MediaPlayer mediaPlayer = new javafx.scene.media.MediaPlayer(sound);
            mediaPlayer.play();
        } catch (Exception e) {
            System.err.println("Error playing card flip sound: " + e.getMessage());
        }
    }

    private void playSafeZoneSound() {
        try {
            javafx.scene.media.Media sound = new javafx.scene.media.Media(new java.io.File("C:\\Users\\LENOVO\\Downloads\\shouting-yeah-7043.mp3").toURI().toString());
            javafx.scene.media.MediaPlayer mediaPlayer = new javafx.scene.media.MediaPlayer(sound);
            mediaPlayer.play();
        } catch (Exception e) {
            System.err.println("Error playing safe zone sound: " + e.getMessage());
        }
    }

    // This is the improved fieldMarble method
    public void fieldMarble() {
        try {
            // Log marble counts before fielding
            Player activePlayer = game.getPlayers().get(game.getCurrentPlayerIndex());
            System.out.println("[DEBUG] BEFORE fielding: Player " + activePlayer.getColour() + 
                              " has " + activePlayer.getMarbles().size() + " marbles in home zone");
            
            // Field the marble using game engine
            // This should remove a marble from the player's collection
            game.fieldMarble();
            
            // Play the fielding sound
            playFieldingSound();
            
            System.out.println("[DEBUG] AFTER fielding: Player " + activePlayer.getColour() + 
                              " has " + activePlayer.getMarbles().size() + " marbles in home zone");
            
            // Force a complete update of all UI elements
            
            // 1. Update marble count for ALL player panels
            Platform.runLater(() -> {
                for (PlayerPanel panel : playerPanels) {
                    panel.updateMarbleCount();
                    System.out.println("[DEBUG] Updated marble count for " + panel.getPlayer().getColour());
                }
            });
            
            // 2. Update the board cells to show the new marble position
            Platform.runLater(() -> {
                updateBoardCells();
                System.out.println("[DEBUG] Updated board cells");
            
                // ADDITIONAL REFRESH for Board - critical for showing new marbles
                boardView.update();
            });
            
            // 3. Update all UI elements
            Platform.runLater(() -> {
                updateUI();
            });
            
            // Show success message
            addMessage("Marble fielded successfully for " + 
                (game.getActivePlayerColour() != null ? game.getActivePlayerColour().toString() : "unknown") + " player");
        } catch (Exception e) {
            System.err.println("[ERROR] Field Error: " + e.getMessage());
            e.printStackTrace();
            showErrorDialog("Field Error", "Cannot field marble: " + e.getMessage());
        }
    }
    
    // Modify the existing keypress handler to use our new method
    private void setupKeyHandlers() {
        setOnKeyPressed((KeyEvent event) -> {
            if (event.getCode() == KeyCode.F) {
                // Only allow fielding if selected card is an Ace or King
                if (selectedCardView != null) {
                    Card selectedCard = selectedCardView.getCard();
                    boolean isAceOrKing = false;
                    if (selectedCard != null) {
                        String cardClass = selectedCard.getClass().getSimpleName();
                        isAceOrKing = cardClass.equals("Ace") || cardClass.equals("King");
                    }
                    if (isAceOrKing) {
                        try {
                            // IMPORTANT: Select the card in the game engine first
                            game.selectCard(selectedCard);
                            
                            // Field a marble
                            fieldMarble();
                            
                            // Update the firepit
                            refreshFirePit();
                            
                            // End turn after fielding
                            handleEndTurn();
                        } catch (Exception e) {
                            showErrorDialog("Fielding Error", "Error fielding marble: " + e.getMessage());
                        }
                    } else {
                        showErrorDialog("Field Error", "You can only field a marble with an Ace or King card.");
                    }
                } else {
                    showErrorDialog("Field Error", "You must select an Ace or King card first.");
                }
            } else if (event.getCode() == KeyCode.X) {
                // Close the game window
                javafx.application.Platform.exit();
            }
        });
    }
    
    // Add new helper method for selecting marbles by cell index
    private void selectMarbleByIndex(int cellIndex) {
        if (cellIndex < 0 || cellIndex >= board.getTrack().size()) {
            showErrorDialog("Invalid Cell", "Cell index must be between 0 and " + (board.getTrack().size() - 1));
            return;
        }
        
        // Get the cell at this index
        Cell cell = board.getTrack().get(cellIndex);
        CellView cellView = cellViews.get(cell);
        
        // Check if there's a marble in this cell
        if (cellView != null && cellView.getMarbleView() != null) {
            MarbleView marbleView = cellView.getMarbleView();
            System.out.println("[DEBUG] Selecting marble by index: " + cellIndex + ", color: " + marbleView.getMarble().getColour());
            
            // Toggle selection and handle as if it was clicked
            marbleView.setSelected(true);
            handleMarbleSelection(marbleView);
        } else {
            showErrorDialog("Empty Cell", "There is no marble at cell index " + cellIndex);
        }
    }
    
    // Update the fire pit card view in the bottom right firepit area only
    public void updateFirePitCard(Card card) {
        System.out.println("[DEBUG] Updating fire pit card with: " + (card != null ? card.getName() : "null card"));
        
        // Always get the latest card from the fire pit if available
        if (card == null && !game.getFirePit().isEmpty()) {
            card = game.getFirePit().get(game.getFirePit().size() - 1);
            System.out.println("[DEBUG] Auto-fetched latest fire pit card: " + card.getName());
        }
        
        // Skip update if no card is provided and fire pit is empty
        if (card == null) {
            System.out.println("[DEBUG] No card to display in fire pit");
            return;
        }

        // Play the card flip sound
        playCardFlipSound();
        
        // Find the fire pit container
        VBox firePitBox = null;
        for (javafx.scene.Node node : ((javafx.scene.layout.Pane)getBottom()).getChildren()) {
            if (node instanceof VBox && "fire-pit-box".equals(node.getId())) {
                firePitBox = (VBox) node;
                break;
            }
        }
        
        if (firePitBox == null) {
            System.out.println("[ERROR] Could not find fire pit container");
            return;
        }
        
        // Always create a fresh CardView to avoid rendering issues
        CardView newCardView = new CardView(null);
        newCardView.setPrefSize(150, 200);
        
        // Set the card AFTER creating the view
        newCardView.setCard(card);
        newCardView.updateDisplay();
        
        // Apply styling and ensure visibility
        newCardView.setStyle("-fx-effect: dropshadow(gaussian, rgba(255,215,0,0.6), 15, 0, 0, 0);");
        newCardView.setOpacity(1.0);
        
        // Clear existing card views from the fire pit box
        if (firePitBox.getChildren().size() > 1) {
            firePitBox.getChildren().remove(1, firePitBox.getChildren().size());
        }
        
        // Add the new card view
        firePitBox.getChildren().add(newCardView);
        
        // Update the reference
        firePitCardView = newCardView;
        
        // Ensure the card view is visible by bringing it to front
        newCardView.toFront();
        
        // Force layout refresh
        firePitBox.requestLayout();
        
        System.out.println("[DEBUG] Successfully added card to fire pit: " + card.getName());
        
        // Also update the BoardView's last played card for highlighting if needed
        if (boardView != null) {
            boardView.setLastPlayedCard(card);
        }
    }
    
    // Add a method to specifically update the fire pit from the Game object
    private void refreshFirePit() {
        System.out.println("[DEBUG] Refreshing fire pit display");
        
        // Check if the game object is available
        if (game == null) {
            System.out.println("[ERROR] Cannot refresh fire pit: game object is null");
            return;
        }
        
        java.util.List<model.card.Card> firePit = game.getFirePit();
        final Card latestCard;
        
        // Get the latest card from the fire pit if available
        if (firePit != null && !firePit.isEmpty()) {
            // Ensure we get the LAST card from the fire pit (most recently played)
            latestCard = firePit.get(firePit.size() - 1);
            System.out.println("[DEBUG] Latest fire pit card: " + latestCard.getName() + 
                              ", Class: " + latestCard.getClass().getSimpleName() + 
                              ", Rank: " + (latestCard instanceof model.card.standard.Standard ? 
                                          ((model.card.standard.Standard)latestCard).getRank() : "N/A") +
                              ", Fire pit size: " + firePit.size());
        } else {
            latestCard = null;
            System.out.println("[DEBUG] Fire pit is empty");
        }
        
        // Force UI update using JavaFX Platform.runLater to ensure thread safety
        Platform.runLater(() -> {
            try {
                // Find the fire pit container first
                VBox firePitBox = null;
                for (javafx.scene.Node node : ((javafx.scene.layout.Pane)getBottom()).getChildren()) {
                    if (node instanceof VBox && "fire-pit-box".equals(node.getId())) {
                        firePitBox = (VBox) node;
                        break;
                    }
                }
                
                if (firePitBox == null) {
                    System.out.println("[ERROR] Could not find fire pit container");
                    return;
                }
                
                // If fire pit is empty, clear the display and return
                if (latestCard == null) {
                    // Clear existing content except the first item (the "FIRE PIT" label)
                    if (firePitBox.getChildren().size() > 1) {
                        firePitBox.getChildren().remove(1, firePitBox.getChildren().size());
                    }
                    return;
                }
                
                // Create a new card view with the latest card - force creation of new view
                CardView newFirePitCardView = new CardView(null);
                newFirePitCardView.setPrefSize(150, 200);
                
                // Set the card and update AFTER creating the view to ensure fresh rendering
                newFirePitCardView.setCard(latestCard);
                newFirePitCardView.updateDisplay();
                
                // Clear existing content except the first item (the "FIRE PIT" label)
                if (firePitBox.getChildren().size() > 1) {
                    firePitBox.getChildren().remove(1, firePitBox.getChildren().size());
                }
                
                // Add our new card to the fire pit box
                firePitBox.getChildren().add(newFirePitCardView);
                
                // Update the reference to the current fire pit card view
                firePitCardView = newFirePitCardView;
                
                // Apply enhanced styling to make card more visible
                newFirePitCardView.setStyle("-fx-effect: dropshadow(gaussian, rgba(255,215,0,0.6), 15, 0, 0, 0);");
                newFirePitCardView.setOpacity(1.0);
                
                System.out.println("[DEBUG] Successfully updated fire pit display with card: " + 
                                  latestCard.getName() + ", Class: " + latestCard.getClass().getSimpleName() + 
                                  (latestCard instanceof model.card.standard.Standard ? ", Rank: " + ((model.card.standard.Standard)latestCard).getRank() : ""));
                
                // Also update the BoardView's last played card for highlighting if needed
                if (boardView != null) {
                    boardView.setLastPlayedCard(latestCard);
                }
                
                // Force the UI to update
                firePitBox.requestLayout();
                
            } catch (Exception e) {
                System.err.println("[ERROR] Failed to refresh fire pit: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }
    
    /**
     * Notify the game screen about marble events (destruction, traps, etc.)
     * This method should be called from the game engine when notable events happen
     * 
     * @param eventType Type of event (e.g., "destroyed", "trap")
     * @param colour Color of the marble involved
     * @param cause Optional cause (e.g., "landed on trap", "burner card", etc.)
     */
    public void notifyMarbleEvent(String eventType, Colour colour, String cause) {
        Platform.runLater(() -> {
            String message = "";
            String playerType = colour == game.getActivePlayerColour() ? "Your" : "CPU " + colour;
            
            if (eventType.equals("destroyed")) {
                message = playerType + " marble was destroyed";
                if (cause != null && !cause.isEmpty()) {
                    message += " (" + cause + ")";
                }
            } else if (eventType.equals("trap")) {
                message = playerType + " marble landed on a trap and was sent home!";
            }
            
            if (!message.isEmpty()) {
                addMessage(message);
            }
        });
    }
    
    private void handleDeselectButton() {
        // Clear the visual selection state
        if (selectedCardView != null) {
            selectedCardView.setSelected(false);
            selectedCardView = null;
        }
        
        // Clear marble selections
        clearMarbleSelections();
        
        // Clear highlights of actionable marbles
        clearHighlights();
        
        // Reset the game state
        try {
            game.deselectAll();
        } catch (Exception e) {
            System.err.println("Error deselecting: " + e.getMessage());
        }
        
        // Disable play button since nothing is selected
        playButton.setDisable(true);
        
        // Show feedback to the user
        addMessage("All selections cleared");
    }
    
    // Helper method to reset the entire game UI state
    private void resetGameUI() {
        // Clear all selections and highlights
        clearMarbleSelections();
        clearHighlights();
        
        // Clear selected card
        if (selectedCardView != null) {
            selectedCardView.setSelected(false);
            selectedCardView = null;
        }
        
        // Update the board view to show current state
        updateBoardCells();
        
        // Make sure all player panels are updated
        for (PlayerPanel panel : playerPanels) {
            panel.updateCards();
        }
    }
    
    // Add method to start background music
    private void startBackgroundMusic() {
        try {
            if (backgroundMusicPlayer == null) {
                Media sound = new Media(new java.io.File("C:\\Users\\LENOVO\\Downloads\\background-music-224633.mp3").toURI().toString());
                backgroundMusicPlayer = new MediaPlayer(sound);
                backgroundMusicPlayer.setCycleCount(MediaPlayer.INDEFINITE); // Loop indefinitely
                backgroundMusicPlayer.setVolume(0.5); // Set volume to 50%
            }
            backgroundMusicPlayer.play();
        } catch (Exception e) {
            System.err.println("Error playing background music: " + e.getMessage());
        }
    }
    
    // Add method to stop background music
    public static void stopBackgroundMusic() {
        if (backgroundMusicPlayer != null) {
            backgroundMusicPlayer.stop();
        }
    }
    
    // Add method to resume background music
    public static void resumeBackgroundMusic() {
        if (backgroundMusicPlayer != null) {
            backgroundMusicPlayer.play();
        }
    }
} 

