package gui;

import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Glow;
import javafx.scene.effect.InnerShadow;
import javafx.scene.effect.Light;
import javafx.scene.effect.Lighting;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.RadialGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Circle;
import model.Colour;
import model.player.Marble;
import javafx.scene.layout.StackPane;
import java.util.Map;
import java.util.HashMap;
import javafx.animation.ScaleTransition;
import javafx.util.Duration;

public class MarbleView extends Circle {
    
    private final Marble marble;
    private boolean isSelected = false;
    private boolean isHighlighted = false;
    private final DropShadow selectionEffect;
    private final Glow highlightEffect;
    
    // Static map to track previous cell positions for each marble
    public static Map<model.player.Marble, gui.CellView> marblePrevCellMap = new HashMap<>();
    
    public MarbleView(Marble marble, double radius) {
        super(radius); // Call Circle constructor with radius
        this.marble = marble;
        
        // CRITICAL: Make absolutely sure this marble can receive events
        this.setMouseTransparent(false);
        
        // Make sure we pick on the actual marble shape, not just the bounding box
        this.setPickOnBounds(false);
        
        // ENHANCED: Make marbles appear on top of all other nodes
        this.setViewOrder(-10000);
        
        // Bring to front in parent container
        this.toFront();
        
        // Setup selection effect (enhanced)
        selectionEffect = new DropShadow();
        selectionEffect.setColor(Color.GOLD);
        selectionEffect.setRadius(20);
        selectionEffect.setSpread(0.4);
        
        // Setup highlight effect (enhanced)
        highlightEffect = new Glow();
        highlightEffect.setLevel(0.8);
        
        setupMarbleStyle();
        
        // Add a specific style class for marbles
        getStyleClass().add("marble");
        
        // SIMPLIFIED CLICK HANDLER - direct and focused
        setOnMouseClicked(e -> {
            System.out.println("[DEBUG] MarbleView clicked: " + marble.getColour());
            
            // Immediately consume the event to prevent propagation
            e.consume();
            
            // Toggle selection state directly - this is a critical simplification
            setSelected(!isSelected);
            System.out.println("[DEBUG] Selection state toggled to: " + isSelected);
            
            // Then notify the game screen
            if (getScene() != null && getScene().getRoot() instanceof GameScreen) {
                GameScreen gameScreen = (GameScreen) getScene().getRoot();
                gameScreen.handleMarbleSelection(this);
            }
        });
        
        // Simplify hover effect to just highlight the marble
        setOnMouseEntered(e -> {
            if (!isSelected) {
                setEffect(selectionEffect);
            }
            e.consume();
        });
        
        setOnMouseExited(e -> {
            if (!isSelected && !isHighlighted) {
                setupMarbleStyle();
            }
            e.consume();
        });
    }
    
    private void setupMarbleStyle() {
        Colour marbleColour = marble.getColour();
        String colorName = marbleColour.toString().toLowerCase();
        getStyleClass().add("marble-" + colorName);
        
        // Create base colors for the marble gradient
        Color baseColor = toJavaFXColor(marbleColour);
        Color lighterColor = baseColor.brighter().brighter();
        Color darkerColor = baseColor.darker();
        
        // Create a radial gradient for a 3D marble effect
        RadialGradient gradient = new RadialGradient(
            45, 0.2, 0.5, 0.3, 0.7, true, CycleMethod.NO_CYCLE,
            new Stop(0, lighterColor.interpolate(Color.WHITE, 0.3)),
            new Stop(0.8, baseColor),
            new Stop(1.0, darkerColor)
        );
        
        setFill(gradient);
        setStroke(Color.BLACK);
        setStrokeWidth(1);
        
        // Add inner shadow for depth
        InnerShadow innerShadow = new InnerShadow();
        innerShadow.setColor(Color.color(0, 0, 0, 0.4));
        innerShadow.setRadius(getRadius() * 0.2);
        innerShadow.setChoke(0.2);
        setEffect(innerShadow);
    }
    
    public Marble getMarble() {
        return marble;
    }
    
    public void setSelected(boolean selected) {
        isSelected = selected;
        updateEffects();
    }
    
    public boolean isSelected() {
        return isSelected;
    }
    
    public void setHighlighted(boolean highlighted) {
        isHighlighted = highlighted;
        updateEffects();
    }
    
    public boolean isHighlighted() {
        return isHighlighted;
    }
    
    private void updateEffects() {
        if (isSelected) {
            DropShadow enhancedSelection = new DropShadow();
            enhancedSelection.setColor(Color.GOLD);
            enhancedSelection.setRadius(20);
            enhancedSelection.setSpread(0.6);
            setEffect(enhancedSelection);
            getStyleClass().add("marble-selected");
            setStroke(Color.WHITE);
            setStrokeWidth(2);
        } else if (isHighlighted) {
            DropShadow highlightShadow = new DropShadow();
            highlightShadow.setColor(Color.WHITE);
            highlightShadow.setRadius(15);
            highlightShadow.setSpread(0.4);
            setEffect(highlightShadow);
            getStyleClass().remove("marble-selected");
            setStroke(Color.WHITE);
            setStrokeWidth(1.5);
        } else {
            setupMarbleStyle(); // Restore original effect
            getStyleClass().remove("marble-selected");
            setStroke(Color.BLACK);
            setStrokeWidth(1);
        }
    }
    
    // Helper method to convert enum Colour to JavaFX Color
    public static Color toJavaFXColor(Colour colour) {
        switch (colour) {
            case RED:
                return Color.rgb(231, 76, 60);
            case BLUE:
                return Color.rgb(52, 152, 219);
            case YELLOW:
                return Color.rgb(241, 196, 15);
            case GREEN:
                return Color.rgb(46, 204, 113);
            default:
                return Color.GRAY;
        }
    }
    
    public void playBounceAnimation() {
        ScaleTransition st = new ScaleTransition(Duration.millis(220), this);
        st.setFromX(1.0);
        st.setFromY(1.0);
        st.setToX(1.25);
        st.setToY(1.25);
        st.setAutoReverse(true);
        st.setCycleCount(2);
        st.play();
    }
} 