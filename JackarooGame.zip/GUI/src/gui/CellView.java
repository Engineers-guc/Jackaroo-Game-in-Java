package gui;

import engine.board.Cell;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import model.Colour;
import model.player.Marble;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.animation.TranslateTransition;
import javafx.util.Duration;
import javafx.geometry.Bounds;
import java.util.HashMap;
import java.util.Map;

public class CellView extends StackPane {
    
    private Cell cell;
    private MarbleView marbleView;
    private boolean isHighlighted = false;
    
    public CellView(Cell cell) {
        this.cell = cell;
        getStyleClass().add("board-cell");
        
        setPrefSize(40, 40);
        
        javafx.scene.Node background;
        boolean isSafeZone = false;
        // Create the cell background
        if (cell != null && cell.getCellType() == engine.board.CellType.SAFE) {
            // Render safe zone as a circle
            javafx.scene.shape.Circle safeCircle = new javafx.scene.shape.Circle(13);
            safeCircle.getStyleClass().add("cell-safe-circle");
            safeCircle.setFill(javafx.scene.paint.Color.web("#fffbe6"));
            safeCircle.setStroke(javafx.scene.paint.Color.web("#bfa14a"));
            safeCircle.setStrokeWidth(2.2);
            background = safeCircle;
            isSafeZone = true;
        } else {
            Rectangle rect = new Rectangle(30, 30);
            rect.getStyleClass().add("cell-background");
            background = rect;
        }
        
        // Add cell type label ONLY for SAFE, BASE, ENTRY
        Label cellTypeLabel = null;
        
        // Only try to access cell properties if cell is not null
        if (cell != null) {
            // Add styling based on cell type
            switch (cell.getCellType()) {
                case SAFE:
                    getStyleClass().add("cell-safe");
                    cellTypeLabel = new Label("S");
                    break;
                case BASE:
                    getStyleClass().add("cell-base");
                    getStyleClass().add("board-cell-base");
                    cellTypeLabel = new Label("B");
                    break;
                case ENTRY:
                    getStyleClass().add("cell-ENTRY");
                    cellTypeLabel = new Label("E");
                    break;
                case NORMAL:
                default:
                    getStyleClass().add("cell-track");
                    // NO LABEL FOR NORMAL CELLS
                    break;
            }
            
            // Don't show trap labels
            if (cell.isTrap()) {
                // No label for trap cells
                getStyleClass().add("cell-trap");
            }
            
            // If the cell has a specific color (for safe zones or bases)
            Colour cellColor = null;
            
            // Prefer the color of the marble if present
            if (cell.getMarble() != null) {
                cellColor = cell.getMarble().getColour();
            } else if (cell.getCellType() == engine.board.CellType.BASE || cell.getCellType() == engine.board.CellType.SAFE) {
                // Try to determine the color from cell properties or position
                for (Colour colour : Colour.values()) {
                    if (cell.toString().toUpperCase().contains(colour.toString())) {
                        cellColor = colour;
                        break;
                    }
                }
            }
            
            // Apply color styling and set the label color
            if (cellTypeLabel != null && cellColor != null) {
                switch (cellColor) {
                    case RED:
                        getStyleClass().add("cell-red");
                        cellTypeLabel.setTextFill(javafx.scene.paint.Color.RED);
                        if (cell.getCellType() == engine.board.CellType.BASE) {
                            getStyleClass().add("board-cell-base-red");
                        } else if (cell.getCellType() == engine.board.CellType.SAFE) {
                            getStyleClass().add("board-cell-home-red");
                            getStyleClass().add("board-cell-home");
                        }
                        break;
                    case BLUE:
                        getStyleClass().add("cell-blue");
                        cellTypeLabel.setTextFill(javafx.scene.paint.Color.BLUE);
                        if (cell.getCellType() == engine.board.CellType.BASE) {
                            getStyleClass().add("board-cell-base-blue");
                        } else if (cell.getCellType() == engine.board.CellType.SAFE) {
                            getStyleClass().add("board-cell-home-blue");
                            getStyleClass().add("board-cell-home");
                        }
                        break;
                    case YELLOW:
                        getStyleClass().add("cell-yellow");
                        cellTypeLabel.setTextFill(javafx.scene.paint.Color.GOLD);
                        if (cell.getCellType() == engine.board.CellType.BASE) {
                            getStyleClass().add("board-cell-base-yellow");
                        } else if (cell.getCellType() == engine.board.CellType.SAFE) {
                            getStyleClass().add("board-cell-home-yellow");
                            getStyleClass().add("board-cell-home");
                        }
                        break;
                    case GREEN:
                        getStyleClass().add("cell-green");
                        cellTypeLabel.setTextFill(javafx.scene.paint.Color.GREEN);
                        if (cell.getCellType() == engine.board.CellType.BASE) {
                            getStyleClass().add("board-cell-base-green");
                        } else if (cell.getCellType() == engine.board.CellType.SAFE) {
                            getStyleClass().add("board-cell-home-green");
                            getStyleClass().add("board-cell-home");
                        }
                        break;
                }
            }
            
            updateMarbleDisplay();
        }
        
        getChildren().add(background);
        
        // Only add the label if it exists
        if (cellTypeLabel != null) {
            cellTypeLabel.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-effect: dropshadow(gaussian, black, 2, 0, 0, 0);");
            getChildren().add(cellTypeLabel);
        }
        setPadding(new Insets(5));
        
        // Make the entire cell clickable for marble selection, but only if no marble was directly clicked
        setOnMouseClicked(e -> {
            // Only handle the click if it wasn't already handled by a marble
            if (!e.isConsumed() && getMarbleView() != null) {
                System.out.println("[DEBUG] CellView clicked with marble: " + getMarbleView().getMarble().getColour());
                if (getScene() != null && getScene().getRoot() instanceof GameScreen) {
                    ((GameScreen) getScene().getRoot()).handleMarbleSelection(getMarbleView());
                }
            }
        });
        
        // Add hover effect if cell contains a marble
        setOnMouseEntered(e -> {
            if (getMarbleView() != null) {
                setStyle("-fx-cursor: hand; -fx-background-color: rgba(255,255,255,0.15);");
            }
        });
        setOnMouseExited(e -> {
            setStyle("");
        });
    }
    
    public void updateMarbleDisplay() {
        // Remove existing marble view if present
        if (marbleView != null) {
            getChildren().remove(marbleView);
            marbleView = null;
        }
        if (cell != null && cell.getMarble() != null) {
            System.out.println("[DEBUG] CellView.updateMarbleDisplay: cell=" + cell + ", marble=" + cell.getMarble());
            marbleView = new MarbleView(cell.getMarble(), 15);

            // --- Marble movement animation ---
            // Track previous positions by marble
            Map<model.player.Marble, CellView> prevPositions = MarbleView.marblePrevCellMap;
            CellView prevCell = prevPositions.get(cell.getMarble());
            prevPositions.put(cell.getMarble(), this);

            getChildren().add(marbleView);
            marbleView.toFront();

            if (prevCell != null && prevCell != this && prevCell.getScene() == getScene()) {
                // Animate from previous cell to this cell
                Point2D from = prevCell.localToScene(prevCell.getWidth() / 2, prevCell.getHeight() / 2);
                Point2D to = this.localToScene(getWidth() / 2, getHeight() / 2);
                double dx = from.getX() - to.getX();
                double dy = from.getY() - to.getY();
                marbleView.setTranslateX(dx);
                marbleView.setTranslateY(dy);
                TranslateTransition tt = new TranslateTransition(Duration.millis(350), marbleView);
                tt.setToX(0);
                tt.setToY(0);
                tt.setOnFinished(e -> marbleView.playBounceAnimation());
                tt.play();
            } else {
                // If not moving, just bounce when fielded
                marbleView.playBounceAnimation();
            }
            // --- End marble movement animation ---

            // CRITICAL FIX: Make cell completely mouse-transparent when it has a marble
            this.setMouseTransparent(true);
            for (javafx.scene.Node child : getChildren()) {
                if (child != marbleView) {
                    child.setMouseTransparent(true);
                    child.setViewOrder(1000);
                }
            }
            marbleView.setMouseTransparent(false);
            marbleView.setViewOrder(-10000);
            setEffect(new javafx.scene.effect.DropShadow(5, javafx.scene.paint.Color.GOLD));
        } else {
            this.setMouseTransparent(false);
            for (javafx.scene.Node child : getChildren()) {
                child.setMouseTransparent(false);
            }
            setEffect(null);
        }
    }
    
    public Cell getCell() {
        return cell;
    }
    
    public MarbleView getMarbleView() {
        return marbleView;
    }
    
    public void setHighlighted(boolean highlighted) {
        isHighlighted = highlighted;
        if (highlighted) {
            if (!getStyleClass().contains("board-cell-highlighted")) {
                getStyleClass().add("board-cell-highlighted");
            }
        } else {
            getStyleClass().remove("board-cell-highlighted");
        }
    }
    
    public boolean isHighlighted() {
        return isHighlighted;
    }
} 