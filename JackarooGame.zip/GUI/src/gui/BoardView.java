package gui;

import java.util.HashMap;
import java.util.Map;

import engine.board.Board;
import engine.board.Cell;
import engine.board.CellType;
import engine.board.SafeZone;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.stage.Screen;
import model.Colour;
import model.player.Marble;

import java.util.ArrayList;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.BorderPane;
import model.card.Card;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;

public class BoardView extends GridPane {
    private Board board;
    private Map<Cell, CellView> cellViewMap = new HashMap<>();
    private GameScreen gameScreen;

    public static final int COLS = 40; // Width of the board
    public static final int ROWS = 12; // Height of the board - updated to 12
    private static final int TRACK_SIZE = 100; // Total cells in the track
    
    private static final int MARGIN = 0; // No margin
    private static final int FIRE_PIT_SIZE = 10; // Size of the fire pit

    private Card lastPlayedCard;
    private CardView firePitCardView;

    private StackPane boardStack;

    public BoardView(Board board, GameScreen gameScreen) {
        this.board = board;
        this.gameScreen = gameScreen;
        getStyleClass().add("board-view");
        
        // Get screen dimensions for responsive sizing (but don't use full screen)
        double screenWidth = Screen.getPrimary().getBounds().getWidth();
        double screenHeight = Screen.getPrimary().getBounds().getHeight();
        
        // Make board 20% smaller than current size
        double boardWidth = screenWidth * 0.68; // Reduced from 0.85 by 20%
        double boardHeight = screenHeight * 0.56; // Reduced from 0.7 by 20%
        
        setPrefSize(boardWidth, boardHeight);
        setMaxSize(boardWidth, boardHeight);
        setMinSize(boardWidth, boardHeight);
        
        // --- WOODEN BORDER ---
        // Create a wooden rectangle as the border background
        Rectangle woodBorder = new Rectangle(boardWidth + 32, boardHeight + 32);
        woodBorder.setArcWidth(24);
        woodBorder.setArcHeight(24);
        woodBorder.setFill(Color.web("#8B5C2A")); // Rich wood color
        woodBorder.setStroke(Color.web("#5C3A1A"));
        woodBorder.setStrokeWidth(12);
        woodBorder.setEffect(new DropShadow(18, Color.web("#3e2412")));

        // Create a StackPane to hold the border and the board
        boardStack = new StackPane();
        boardStack.setAlignment(Pos.CENTER);
        boardStack.getChildren().addAll(woodBorder, this);
        boardStack.setPadding(new Insets(16));

        // --- WOODEN TRACK BORDER ---
        // Calculate the size of the track area (excluding safe zones and center)
        double trackBorderThickness = 8;
        double trackWidth = boardWidth - 24; // slightly inside the outer border
        double trackHeight = boardHeight - 24;
        Rectangle trackBorder = new Rectangle(trackWidth, trackHeight);
        trackBorder.setArcWidth(18);
        trackBorder.setArcHeight(18);
        trackBorder.setFill(Color.TRANSPARENT);
        trackBorder.setStroke(Color.web("#a97c50"));
        trackBorder.setStrokeWidth(trackBorderThickness);
        trackBorder.setEffect(new DropShadow(10, Color.web("#6b4f2a")));
        // Insert trackBorder above woodBorder but below the board grid
        boardStack.getChildren().add(1, trackBorder);
        // --- END WOODEN TRACK BORDER ---
        
        // Configure GridPane
        setHgap(0);
        setVgap(0);
        setAlignment(Pos.CENTER);
        setPadding(new Insets(10));
        
        // Set style
        setStyle("-fx-background-image: url('/gui/board_bg_western.png'); -fx-background-size: cover; -fx-background-position: center; -fx-border-color: #5c3a1a; -fx-border-width: 6px; -fx-border-radius: 8px;");
        
        // Create board layout
        setupGridConstraints(boardWidth, boardHeight);
        createTrackCells();
        createSafePaths();
        
        // Add shadow effect
        setEffect(new DropShadow(10, Color.BLACK));
    }
    
    /**
     * Sets up column and row constraints for the grid
     */
    private void setupGridConstraints(double boardWidth, double boardHeight) {
        // Calculate total grid size with border
        double totalGridWidth = boardWidth - 16; // Subtract border width
        double totalGridHeight = boardHeight - 16; // Subtract border height
        
        // Calculate cell dimensions
        double cellWidth = totalGridWidth / COLS;
        double cellHeight = totalGridHeight / ROWS;
        
        // Clear existing constraints
        getColumnConstraints().clear();
        getRowConstraints().clear();
        
        // Create column constraints
        for (int i = 0; i < COLS; i++) {
            ColumnConstraints colConstraint = new ColumnConstraints();
            colConstraint.setPrefWidth(cellWidth);
            colConstraint.setMinWidth(cellWidth);
            colConstraint.setMaxWidth(cellWidth);
            colConstraint.setHalignment(HPos.CENTER);
            getColumnConstraints().add(colConstraint);
        }
        
        // Create row constraints
        for (int i = 0; i < ROWS; i++) {
            RowConstraints rowConstraint = new RowConstraints();
            rowConstraint.setPrefHeight(cellHeight);
            rowConstraint.setMinHeight(cellHeight);
            rowConstraint.setMaxHeight(cellHeight);
            rowConstraint.setValignment(VPos.CENTER);
            getRowConstraints().add(rowConstraint);
        }
        
        System.out.println("Created grid with " + ROWS + " rows and " + COLS + " columns");
    }
    
    private void createTrackCells() {
        ArrayList<Cell> track = board.getTrack();
        System.out.println("Creating track with " + track.size() + " cells");
        
        // Calculate cell positions
        int[][] positions = calculateTrackPositions();
        
        // Create cells
        for (int i = 0; i < track.size(); i++) {
            Cell cell = track.get(i);
            CellView cellView = new CellView(cell);
            
            // Get position
            int row = positions[i][0];
            int col = positions[i][1];
            
            // Make cell clickable for marble selection
            cellView.setOnMouseClicked(e -> {
                if (cellView.getMarbleView() != null) {
                    gameScreen.handleMarbleSelection(cellView.getMarbleView());
                }
            });
            
            // Color cell based on type
            String cellStyle = "-fx-border-color: #000000; -fx-border-width: 0.5px;";
            if (i == 0 || i == 39 || i == 49 || i == 89 || cell.getCellType() == CellType.BASE) {
                // Change from reddish to normal beige color for base cells
                cellStyle = "-fx-background-color: #d4bc7d; " + cellStyle;
            } else if (cell.isTrap()) {
                // Change from blue to normal beige color for trap cells
                cellStyle = "-fx-background-color: #d4bc7d; " + cellStyle;
            } else {
                // Beige for normal cells
                cellStyle = "-fx-background-color: #d4bc7d; " + cellStyle;
            }
            
            cellView.setStyle(cellStyle);
            
            // Add cell to grid
            add(cellView, col, row);
            cellViewMap.put(cell, cellView);
            
            // Add index number to all cells
            javafx.scene.control.Label indexLabel = new javafx.scene.control.Label(String.valueOf(i));
            indexLabel.setFont(javafx.scene.text.Font.font("Arial", javafx.scene.text.FontWeight.BOLD, 10));
            indexLabel.setTextFill(javafx.scene.paint.Color.BLACK);
            indexLabel.setStyle("-fx-background-color: rgba(255,255,255,0.7); -fx-padding: 0 2 0 2; -fx-background-radius: 3px;");
            indexLabel.setMouseTransparent(true); // Let clicks pass through
            indexLabel.setAlignment(javafx.geometry.Pos.TOP_RIGHT);
            // Add label as the last child so it's always on top
            cellView.getChildren().add(indexLabel);
        }
    }
    
    private int[][] calculateTrackPositions() {
        int[][] positions = new int[TRACK_SIZE][2];
        
        // EXACTLY 40-10-40-10 = 100 cells total
        // Numbered counterclockwise from bottom-left
        
        int index = 0;
        
        // Bottom row - 40 cells (0-39) from left to right
        for (int col = 0; col < 40 && index < 100; col++) {
            positions[index] = new int[]{ROWS-1, col};
            index++;
        }
        
        // Right column - 10 cells (40-49) from bottom to top
        for (int row = ROWS-2; row >= 0 && index < 100; row--) { // Changed to go all the way to row 0 to include top corner
            positions[index] = new int[]{row, COLS-1};
            index++;
        }
        
        // Top row - 40 cells (50-89) from right to left
        for (int col = COLS-2; col >= 0 && index < 100; col--) {
            positions[index] = new int[]{0, col}; // Top row is at row 0
            index++;
        }
        
        // Left column - 10 cells (90-99) from top to bottom
        for (int row = 1; row < ROWS-1 && index < 100; row++) {
            positions[index] = new int[]{row, 0};
            index++;
        }
        
        // Output distribution for verification
        System.out.println("Track distribution:");
        System.out.println("Bottom cells: " + 40);
        System.out.println("Right cells: " + 10);
        System.out.println("Top cells: " + 40);
        System.out.println("Left cells: " + 10);
        System.out.println("Total cells created: " + index);
        
        return positions;
    }
    
    private void createSafePaths() {
        int centerRow = ROWS / 2;
        int centerCol = COLS / 2;
        int[][][] safezonePositions = new int[][][] {
            // BLUE (up)
            { {centerRow-4, centerCol}, {centerRow-3, centerCol}, {centerRow-2, centerCol}, {centerRow-1, centerCol} },
            // RED (right)
            { {centerRow, centerCol+4}, {centerRow, centerCol+3}, {centerRow, centerCol+2}, {centerRow, centerCol+1} },
            // GREEN (down)
            { {centerRow+1, centerCol}, {centerRow+2, centerCol}, {centerRow+3, centerCol}, {centerRow+4, centerCol} },
            // YELLOW (left)
            { {centerRow, centerCol-4}, {centerRow, centerCol-3}, {centerRow, centerCol-2}, {centerRow, centerCol-1} }
        };
        java.util.List<engine.board.SafeZone> safeZones = board.getSafeZones();
        for (int i = 0; i < 4; i++) {
            model.Colour playerColour = safeZones.get(i).getColour();
            String colorCode = getColorString(playerColour);
            for (int j = 0; j < 4; j++) {
                int row = safezonePositions[i][j][0];
                int col = safezonePositions[i][j][1];
                
                // Get the actual cell from the safe zone
                Cell cell = safeZones.get(i).getCells().get(j);
                
                // Create the cell view with the actual safe zone cell
                CellView cellView = new CellView(cell);
                
                cellView.setPrefSize(25.0, 25.0);
                cellView.setMinSize(22.0, 22.0);
                cellView.setMaxSize(28.0, 28.0);
                cellView.setStyle(
                    "-fx-background-color: " + colorCode + ";" +
                    "-fx-border-color: black;" +
                    "-fx-border-width: 1.5px;" +
                    "-fx-background-radius: 5px;" +
                    "-fx-border-radius: 5px;"
                );
                
                // Add a clearer marker for safe zone cells
                javafx.scene.control.Label safeLabel = new javafx.scene.control.Label("S");
                safeLabel.setStyle("-fx-font-size: 10px; -fx-font-weight: bold; -fx-text-fill: black;");
                cellView.getChildren().add(safeLabel);
                
                // Make cell clickable for marble selection
                cellView.setOnMouseClicked(e -> {
                    if (cellView.getMarbleView() != null) {
                        gameScreen.handleMarbleSelection(cellView.getMarbleView());
                    }
                });
                
                // Add the cell view to the grid
                add(cellView, col, row);
                
                // IMPORTANT: Add to cellViewMap so it gets updated when board state changes
                cellViewMap.put(cell, cellView);
                
                // Call updateMarbleDisplay after adding to map
                cellView.updateMarbleDisplay();
            }
        }
        
        // Debug output to confirm safe zone cells are properly added
        System.out.println("[DEBUG] Created " + (4 * 4) + " safe zone cells, total cell views: " + cellViewMap.size());
    }
    
    // Simple helper to convert model.Colour to CSS color string
    private String getColorString(model.Colour colour) {
        switch (colour) {
            case BLUE: return "#0000FF";
            case RED: return "#FF0000";
            case GREEN: return "#00FF00";
            case YELLOW: return "#FFFF00";
            default: return "#808080"; // gray
        }
    }

    public void update() {
        System.out.println("[DEBUG] BoardView.update: Updating all cell views (" + cellViewMap.size() + " cells)");
        
        // First update all cells in the track
        for (Cell cell : cellViewMap.keySet()) {
            CellView cellView = cellViewMap.get(cell);
            if (cellView != null) {
                cellView.updateMarbleDisplay();
            }
        }
        
        // Also check safe zone cells specifically
        for (SafeZone safeZone : board.getSafeZones()) {
            for (Cell safeCell : safeZone.getCells()) {
                CellView cellView = cellViewMap.get(safeCell);
                if (cellView != null) {
                    // Force update with additional logging
                    if (safeCell.getMarble() != null) {
                        System.out.println("[DEBUG] Updating safe zone cell with marble: " + 
                            safeCell.getMarble().getColour() + " at " + safeZone.getColour() + " safe zone");
                    }
                    cellView.updateMarbleDisplay();
                } else {
                    System.out.println("[WARNING] Safe zone cell not found in cellViewMap: " + safeCell);
                }
            }
        }
    }

    public Map<Cell, CellView> getCellViewMap() {
        return cellViewMap;
    }
    
    // These methods can be used to position player panels on the left and right of the fire pit
    public int[] getLeftUpperPosition() {
        int centerCol = COLS / 2;
        int centerRow = ROWS / 2;
        
        int pitWidth = (int)(COLS / 6 * 0.7);
        int pitHeight = (int)(ROWS / 2 * 0.7);
        
        int fireLeftCol = centerCol - (pitWidth / 2);
        return new int[]{centerRow - (pitHeight / 2) - 1, fireLeftCol - 4}; // Position closer to fire pit
    }
    
    public int[] getLeftLowerPosition() {
        int centerCol = COLS / 2;
        int centerRow = ROWS / 2;
        
        int pitWidth = (int)(COLS / 6 * 0.7);
        int pitHeight = (int)(ROWS / 2 * 0.7);
        
        int fireLeftCol = centerCol - (pitWidth / 2);
        return new int[]{centerRow + (pitHeight / 2), fireLeftCol - 4}; // Position closer to fire pit
    }
    
    public int[] getRightUpperPosition() {
        int centerCol = COLS / 2;
        int centerRow = ROWS / 2;
        
        int pitWidth = (int)(COLS / 6 * 0.7);
        int pitHeight = (int)(ROWS / 2 * 0.7);
        
        int fireRightCol = centerCol + (pitWidth / 2);
        return new int[]{centerRow - (pitHeight / 2) - 1, fireRightCol + 1}; // Position closer to fire pit
    }
    
    public int[] getRightLowerPosition() {
        int centerCol = COLS / 2;
        int centerRow = ROWS / 2;
        
        int pitWidth = (int)(COLS / 6 * 0.7);
        int pitHeight = (int)(ROWS / 2 * 0.7);
        
        int fireRightCol = centerCol + (pitWidth / 2);
        return new int[]{centerRow + (pitHeight / 2), fireRightCol + 1}; // Position closer to fire pit
    }

    public void setLastPlayedCard(Card card) {
        this.lastPlayedCard = card;
        // No longer need to update visual elements - just store the reference
    }

    public StackPane getBoardStack() {
        return boardStack;
    }
} 