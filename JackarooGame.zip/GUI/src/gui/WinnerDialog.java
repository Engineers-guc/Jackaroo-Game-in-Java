package gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;
import model.Colour;

public class WinnerDialog {
    
    private Stage dialogStage;
    private JackarooApp app;
    private MediaPlayer mediaPlayer;
    
    public WinnerDialog(Window owner, String winnerName, Colour winnerColour, JackarooApp app) {
        this.app = app;
        
        // Get screen dimensions for responsive sizing
        double screenWidth = Screen.getPrimary().getBounds().getWidth();
        double screenHeight = Screen.getPrimary().getBounds().getHeight();
        
        // Create the dialog stage with responsive dimensions
        dialogStage = new Stage();
        dialogStage.initOwner(owner);
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.initStyle(StageStyle.DECORATED);
        dialogStage.setTitle("Game Over");
        dialogStage.setResizable(true);
        
        // Create the content
        VBox content = createContent(winnerName, winnerColour, screenWidth, screenHeight);
        
        // Set up the scene
        Scene scene = new Scene(content);
        scene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());
        
        dialogStage.setScene(scene);
        
        // Clean up media player when dialog is closed
        dialogStage.setOnCloseRequest(event -> {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.dispose();
            }
        });
    }
    
    private VBox createContent(String winnerName, Colour winnerColour, double screenWidth, double screenHeight) {
        // Create video player
        String videoPath = "C:\\Users\\LENOVO\\Downloads\\WINNERSCREENVOD.mp4";
        Media media = new Media(new java.io.File(videoPath).toURI().toString());
        mediaPlayer = new MediaPlayer(media);
        MediaView mediaView = new MediaView(mediaPlayer);
        
        // Set video size to fill the screen while maintaining aspect ratio
        mediaView.setFitWidth(screenWidth);
        mediaView.setFitHeight(screenHeight);
        mediaView.setPreserveRatio(true);
        
        // Create buttons
        Button playAgainButton = new Button("Play Again");
        playAgainButton.getStyleClass().add("primary-button");
        playAgainButton.setPrefWidth(screenWidth * 0.15);
        playAgainButton.setPrefHeight(screenHeight * 0.05);
        playAgainButton.setOnAction(e -> {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
            }
            dialogStage.close();
            app.showWelcomeScreen();
        });
        
        Button exitButton = new Button("Exit Game");
        exitButton.setPrefWidth(screenWidth * 0.15);
        exitButton.setPrefHeight(screenHeight * 0.05);
        exitButton.setOnAction(e -> {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
            }
            dialogStage.close();
            System.exit(0);
        });
        
        // Layout buttons
        HBox buttonBox = new HBox(screenWidth * 0.02, playAgainButton, exitButton);
        buttonBox.setAlignment(Pos.CENTER);
        
        // Create main content container
        VBox content = new VBox(screenHeight * 0.03, mediaView, buttonBox);
        content.setPadding(new Insets(screenHeight * 0.04));
        content.setAlignment(Pos.CENTER);
        content.setSpacing(screenHeight * 0.025);
        content.getStyleClass().add("winner-dialog");
        
        // Start playing the video
        mediaPlayer.setAutoPlay(true);
        mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE); // Loop the video
        
        return content;
    }
    
    public void show() {
        dialogStage.show();
    }
} 