package gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Screen;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;

public class GameStoryScreen extends BorderPane {
    private JackarooApp app;
    private MediaPlayer mediaPlayer;

    public GameStoryScreen(JackarooApp app) {
        this.app = app;
        setUpUI();
        
        // Stop background music when game story screen is shown
        GameScreen.stopBackgroundMusic();
    }

    private void setUpUI() {
        double screenWidth = Screen.getPrimary().getBounds().getWidth();
        double screenHeight = Screen.getPrimary().getBounds().getHeight();

        String videoPath = "C:\\Users\\LENOVO\\Downloads\\GAMESTORYVOD.mp4";
        try {
            System.out.println("[DEBUG] Attempting to load video from: " + videoPath);
            java.io.File videoFile = new java.io.File(videoPath);
            if (!videoFile.exists()) {
                throw new RuntimeException("Video file not found at: " + videoPath);
            }
            
            Media media = new Media(videoFile.toURI().toString());
            // Listen for errors on the Media object
            media.setOnError(() -> {
                System.err.println("[ERROR] Media Error: " + media.getError());
            });
            mediaPlayer = new MediaPlayer(media);
            mediaPlayer.setOnError(() -> {
                System.err.println("[ERROR] MediaPlayer Error: " + mediaPlayer.getError());
            });
            MediaView mediaView = new MediaView(mediaPlayer);
            mediaView.setPreserveRatio(false);
            // Bind to parent size dynamically
            StackPane videoPane = new StackPane(mediaView);
            videoPane.setPrefSize(screenWidth, screenHeight);
            videoPane.setMinSize(0, 0);
            videoPane.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
            mediaView.fitWidthProperty().bind(videoPane.widthProperty());
            mediaView.fitHeightProperty().bind(videoPane.heightProperty());
            // Make sure the StackPane fills the BorderPane
            setPrefSize(screenWidth, screenHeight);
            setMinSize(0, 0);
            setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

            // Back button
            Button backButton = new Button("Back");
            backButton.getStyleClass().add("welcome-button");
            backButton.setPrefWidth(screenWidth * 0.15);
            backButton.setPrefHeight(screenHeight * 0.05);
            backButton.setOnAction(e -> {
                if (mediaPlayer != null) {
                    mediaPlayer.stop();
                    mediaPlayer.dispose();
                }
                app.showWelcomeScreen();
            });

            // Overlay the button at the bottom center
            VBox overlay = new VBox();
            overlay.setAlignment(Pos.BOTTOM_CENTER);
            overlay.setPadding(new Insets(0, 0, screenHeight * 0.04, 0));
            overlay.getChildren().add(backButton);

            StackPane root = new StackPane(videoPane, overlay);
            // Make sure root fills the parent
            root.setPrefSize(screenWidth, screenHeight);
            root.setMinSize(0, 0);
            root.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
            setCenter(root);

            // Start playing the video
            mediaPlayer.setAutoPlay(true);
            mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE); // Loop the video
            mediaPlayer.setOnReady(() -> {
                System.out.println("[DEBUG] Video is ready to play");
                System.out.println("[DEBUG] MediaView size: " + mediaView.getFitWidth() + "x" + mediaView.getFitHeight());
            });
            mediaPlayer.setOnPlaying(() -> {
                System.out.println("[DEBUG] Video is playing");
            });
            mediaPlayer.setOnEndOfMedia(() -> {
                System.out.println("[DEBUG] Video reached end, looping");
            });
        } catch (Exception e) {
            System.err.println("[ERROR] Failed to load video: " + e.getMessage());
            e.printStackTrace();
            Label errorLabel = new Label("Failed to load video: " + e.getMessage());
            errorLabel.setTextFill(Color.RED);
            errorLabel.setStyle("-fx-font-size: 16px;");
            Button backButton = new Button("Back");
            backButton.setOnAction(event -> app.showWelcomeScreen());
            VBox errorContent = new VBox(20, errorLabel, backButton);
            errorContent.setAlignment(Pos.CENTER);
            setCenter(errorContent);
        }
    }
} 