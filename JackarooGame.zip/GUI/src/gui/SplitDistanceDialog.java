package gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;

/**
 * Dialog for selecting the split distance when playing the Seven card.
 * Allows the user to choose how to split the 7 steps between two marbles.
 */
public class SplitDistanceDialog {
    
    private Stage dialogStage;
    private int selectedValue = 3; // Default split distance is 3
    
    /**
     * Create a new split distance dialog.
     * 
     * @param owner The owner window of this dialog
     */
    public SplitDistanceDialog(Window owner) {
        // Create stage
        dialogStage = new Stage();
        dialogStage.initOwner(owner);
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.setTitle("Split Distance");
        dialogStage.setResizable(false);
        
        // Create the content pane
        VBox contentPane = new VBox(15);
        contentPane.setPadding(new Insets(20));
        contentPane.setStyle("-fx-background-color: #222;");
        
        // Title
        Text titleText = new Text("Choose Split Distance");
        titleText.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        titleText.setFill(Color.WHITE);
        
        // Description
        Label descLabel = new Label("Move the slider to choose how to split 7 steps between your two marbles.");
        descLabel.setFont(Font.font("Arial", 14));
        descLabel.setTextFill(Color.WHITE);
        descLabel.setWrapText(true);
        
        // Display for showing the split values
        HBox splitDisplay = new HBox(20);
        splitDisplay.setAlignment(Pos.CENTER);
        
        Label firstMarbleLabel = new Label("First Marble: 3");
        firstMarbleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        firstMarbleLabel.setTextFill(Color.WHITE);
        
        Label secondMarbleLabel = new Label("Second Marble: 4");
        secondMarbleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        secondMarbleLabel.setTextFill(Color.WHITE);
        
        splitDisplay.getChildren().addAll(firstMarbleLabel, secondMarbleLabel);
        
        // Slider for selecting the split distance
        Slider splitSlider = new Slider(1, 6, 3); // Min 1, Max 6, Default 3
        splitSlider.setShowTickMarks(true);
        splitSlider.setShowTickLabels(true);
        splitSlider.setMajorTickUnit(1);
        splitSlider.setMinorTickCount(0);
        splitSlider.setSnapToTicks(true);
        splitSlider.setPrefWidth(300);
        
        // Update the display when slider changes
        splitSlider.valueProperty().addListener((obs, oldValue, newValue) -> {
            int value = newValue.intValue();
            selectedValue = value;
            firstMarbleLabel.setText("First Marble: " + value);
            secondMarbleLabel.setText("Second Marble: " + (7 - value));
        });
        
        // Buttons
        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        
        Button cancelButton = new Button("Cancel");
        cancelButton.setPrefWidth(100);
        cancelButton.setOnAction(e -> {
            selectedValue = -1; // Mark as canceled
            dialogStage.close();
        });
        
        Button confirmButton = new Button("Confirm");
        confirmButton.setPrefWidth(100);
        confirmButton.setOnAction(e -> dialogStage.close());
        
        buttonBox.getChildren().addAll(cancelButton, confirmButton);
        
        // Add all components to the content pane
        contentPane.getChildren().addAll(titleText, descLabel, splitDisplay, splitSlider, buttonBox);
        contentPane.setAlignment(Pos.CENTER);
        
        // Create scene
        Scene scene = new Scene(contentPane, 400, 250);
        dialogStage.setScene(scene);
        
        // Add CSS for styling if available
        try {
            scene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());
        } catch (Exception e) {
            // CSS not found, continue without it
        }
    }
    
    /**
     * Show the dialog and wait for user input.
     * 
     * @return The selected split distance (1-6) or -1 if canceled
     */
    public int showAndWait() {
        dialogStage.showAndWait();
        return selectedValue;
    }
} 