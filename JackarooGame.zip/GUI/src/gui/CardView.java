package gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import model.card.Card;
import model.card.standard.Standard;
import model.card.wild.Wild;
import javafx.animation.ScaleTransition;
import javafx.util.Duration;

public class CardView extends BorderPane {
    
    private Card card;
    private boolean isSelected = false;
    private ImageView cardImageView;
    private GameScreen gameScreen;
    private static final double DEFAULT_WIDTH = 120;
    private static final double DEFAULT_HEIGHT = 180;
    
    // Constructor with just card (for backward compatibility)
    public CardView(Card card) {
        this(card, null);
    }
    
    // New constructor with GameScreen reference
    public CardView(Card card, GameScreen gameScreen) {
        this.card = card;
        this.gameScreen = gameScreen;
        setPrefSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
        getStyleClass().add("card");
        
        // IMPORTANT: Try to load and display the card image
        System.out.println("Setting up CardView for " + (card != null ? card.getName() : "null card"));
        if (!setupCardImage()) {
            System.out.println("Falling back to text-based card for " + (card != null ? card.getName() : "null card"));
            setupTextBasedCard();
        } else {
            System.out.println("Successfully loaded image card for " + (card != null ? card.getName() : "null card"));
        }
    }
    
    // Returns true if image was loaded, false otherwise
    private boolean setupCardImage() {
        if (card == null) return false;
        
        String imagePath = getCardImagePath(card);
        System.out.println("Trying to load card image: " + imagePath);
        
        try {
            // Clear any existing card image 
            if (cardImageView != null) {
                cardImageView = null;
            }
            
            // Try multiple resource loading approaches
            Image cardImage = null;
            
            // Method 1: Direct classpath resource stream
            try {
                System.out.println("Method 1: Direct getResourceAsStream");
                cardImage = new Image(getClass().getResourceAsStream(imagePath));
                if (cardImage == null || cardImage.isError()) {
                    System.out.println("Method 1 failed");
                    throw new Exception("Image not loaded with Method 1");
                }
            } catch (Exception e) {
                // Method 2: Try with class loader
                try {
                    System.out.println("Method 2: Using ClassLoader");
                    cardImage = new Image(getClass().getClassLoader().getResourceAsStream(imagePath.substring(1)));
                    if (cardImage == null || cardImage.isError()) {
                        System.out.println("Method 2 failed");
                        throw new Exception("Image not loaded with Method 2");
                    }
                } catch (Exception e2) {
                    // Method 3: Try with absolute path in resources folder
                    try {
                        System.out.println("Method 3: Absolute file path");
                        String absPath = "file:GUI/resources" + imagePath;
                        System.out.println("Trying: " + absPath);
                        cardImage = new Image(absPath);
                        if (cardImage == null || cardImage.isError()) {
                            System.out.println("Method 3 failed");
                            throw new Exception("Image not loaded with Method 3");
                        }
                    } catch (Exception e3) {
                        // Method 4: Try src/resources as direct file
                        try {
                            System.out.println("Method 4: Source folder path");
                            String srcPath = "file:GUI/src/resources" + imagePath;
                            System.out.println("Trying: " + srcPath);
                            cardImage = new Image(srcPath);
                            if (cardImage == null || cardImage.isError()) {
                                System.out.println("Method 4 failed");
                                throw new Exception("Image not loaded with Method 4");
                            }
                        } catch (Exception e4) {
                            // Method 5: Try another path variant for special cards
                            try {
                                System.out.println("Method 5: Special card path variant");
                                String specialPath = "file:GUI/resources/cards/" + imagePath.substring(imagePath.lastIndexOf("/") + 1);
                                System.out.println("Trying: " + specialPath);
                                cardImage = new Image(specialPath);
                                if (cardImage == null || cardImage.isError()) {
                                    System.out.println("Method 5 failed");
                                    throw new Exception("Image not loaded with Method 5");
                                }
                            } catch (Exception e5) {
                                // Method 6: Try yet another path for special cards
                                try {
                                    System.out.println("Method 6: Alternative special card path");
                                    // For paths like "/cards/burner_card_64x64.png", try "burner_card_64x64.png" directly
                                    String alternativePath = "file:GUI/src/resources/cards/" + imagePath.substring(imagePath.lastIndexOf("/") + 1);
                                    System.out.println("Trying: " + alternativePath);
                                    cardImage = new Image(alternativePath);
                                    if (cardImage == null || cardImage.isError()) {
                                        System.out.println("Method 6 failed");
                                        throw new Exception("Image not loaded with Method 6");
                                    }
                                } catch (Exception e6) {
                                    System.out.println("All methods failed");
                                    return false;
                                }
                            }
                        }
                    }
                }
            }
            
            if (cardImage != null && !cardImage.isError()) {
                System.out.println("Image loaded successfully!");
                cardImageView = new ImageView(cardImage);
                cardImageView.setFitWidth(DEFAULT_WIDTH);
                cardImageView.setFitHeight(DEFAULT_HEIGHT);
                cardImageView.setPreserveRatio(true);
                cardImageView.setSmooth(true);
                cardImageView.setCache(true);
                
                // Create a fresh StackPane to hold the image
                StackPane cardPane = new StackPane(cardImageView);
                cardPane.getStyleClass().add("card-image-container");
                setCenter(cardPane);
                return true;
            } else {
                System.out.println("Failed to load image for card: " + (card != null ? card.getName() : "null"));
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error loading card image: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private String getCardImagePath(Card card) {
        if (card == null) {
            return "/gui/card_back.png";
        }
        
        System.out.println("[DEBUG CardView.getCardImagePath] Processing card: " + card.getName() + " (Class: " + card.getClass().getSimpleName() + ")");

        // Handle wild cards - special cards like Burner and Saver
        if (card instanceof Wild) {
            // Simplify wild card detection by checking class type first
            if (card instanceof model.card.wild.Burner || 
                card.getClass().getSimpleName().equals("Burner")) {
                System.out.println("[DEBUG CardView.getCardImagePath] Detected Burner card by class type");
                return "/gui/burner_card_64x64.png";
            } else if (card instanceof model.card.wild.Saver || 
                       card.getClass().getSimpleName().equals("Saver")) {
                System.out.println("[DEBUG CardView.getCardImagePath] Detected Saver card by class type");
                return "/gui/saver_card_64x64.png";
            }
            
            // Fallback to name-based detection if class type check didn't work
            String cardName = card.getName().toUpperCase();
            System.out.println("[DEBUG CardView.getCardImagePath] Wild card name (uppercase): " + cardName);
            if (cardName.contains("BURNER") || 
                cardName.contains("MARBLE BURNER") || 
                cardName.contains("MARBLEBURNER") ||
                cardName.contains("DESTROYS")) {
                System.out.println("[DEBUG CardView.getCardImagePath] Using dedicated burner image for Burner card (name-based)");
                return "/gui/burner_card_64x64.png";
            } else if (cardName.contains("SAVER") || 
                       cardName.contains("MARBLE SAVER") || 
                       cardName.contains("MARBLESAVER") ||
                       cardName.contains("SAFE ZONE")) {
                System.out.println("[DEBUG CardView.getCardImagePath] Using dedicated saver image for Saver card (name-based)");
                return "/gui/saver_card_64x64.png";
            }
            
            System.out.println("[DEBUG CardView.getCardImagePath] Using card_back.png for unknown wild card: " + card.getName());
            return "/gui/card_back.png";
        } 
        // Handle standard cards
        else if (card instanceof Standard) {
            Standard standardCard = (Standard) card;
            String suit = "";
            String rank = "";
            
            System.out.println("[DEBUG CardView.getCardImagePath] Standard card. Suit from card object: " + standardCard.getSuit() + ", Rank from card object: " + standardCard.getRank());

            switch(standardCard.getSuit()) {
                case HEART: suit = "hearts"; break;
                case DIAMOND: suit = "diamonds"; break;
                case SPADE: suit = "spades"; break;
                case CLUB: suit = "clubs"; break;
                default: 
                    System.out.println("[DEBUG CardView.getCardImagePath] Unknown suit: " + standardCard.getSuit() + " for card " + card.getName());
                    return "/gui/card_back.png"; // Fallback for unknown suit
            }
            
            int cardRank = standardCard.getRank();
            if (cardRank == 1) {
                rank = "A";
            } else if (cardRank == 11) {
                rank = "J";
            } else if (cardRank == 12) {
                rank = "Q";
            } else if (cardRank == 13) {
                rank = "K";
            } else if (cardRank >= 2 && cardRank <= 9) {
                rank = String.format("%02d", cardRank); 
            } else if (cardRank == 10) {
                rank = "10";
            } else {
                System.out.println("[DEBUG CardView.getCardImagePath] Unknown rank: " + cardRank + " for card " + card.getName());
                return "/gui/card_back.png"; // Fallback for unknown rank
            }
            
            if (suit.isEmpty() || rank.isEmpty()) {
                System.out.println("[DEBUG CardView.getCardImagePath] Suit or rank is empty. Suit: '" + suit + "', Rank: '" + rank + "' for card " + card.getName());
                return "/gui/card_back.png";
            }
            
            String imagePath = String.format("/gui/card_%s_%s.png", suit, rank);
            System.out.println("[DEBUG CardView.getCardImagePath] Standard card details - Suit: " + suit + ", Rank: " + rank + ", Original Rank from card: " + cardRank + ". Generated path: " + imagePath);
            return imagePath;
        }
        
        // Try a name-based fallback for any unclassified cards
        String cardName = card.getName().toUpperCase();
        
        // Try to detect special cards based on name
        if (cardName.contains("BURNER") || 
            cardName.contains("MARBLE BURNER") ||
            cardName.contains("DESTROY")) {
            return "/gui/burner_card_64x64.png";
        } else if (cardName.contains("SAVER") || 
                  cardName.contains("MARBLE SAVER") ||
                  cardName.contains("SAFE ZONE")) {
            return "/gui/saver_card_64x64.png";
        }
        
        System.out.println("[DEBUG CardView.getCardImagePath] Card is not Wild or Standard, returning card_back.png for: " + card.getName());
        return "/gui/card_back.png";
    }
    
    private void setupTextBasedCard() {
        getChildren().clear();
        if (this.card == null) {
            getStyleClass().add("card-empty");
            setStyle("-fx-background-color: #444; -fx-border-color: #666; -fx-border-width: 1px;");
            Label emptyLabel = new Label("No Card");
            emptyLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
            emptyLabel.setAlignment(Pos.CENTER);
            setCenter(emptyLabel);
            return;
        }

        String cardType = "";
        String colorStyle = "";
        String suit = "";
        String rank = "";
        String name = card.getName();

        if (card instanceof Standard) {
            Standard standardCard = (Standard) card;
            String[] parts = standardCard.getName().split("_");
            suit = parts[0];
            rank = formatCardName(standardCard.getName());
            cardType = "standard";
            if (suit.contains("HEART") || suit.contains("DIAMOND")) {
                colorStyle = "card-red";
            } else {
                colorStyle = "card-black";
            }
        } else if (card instanceof Wild) {
            cardType = "wild";
            colorStyle = "card-wild";
            suit = card.getName();
            rank = formatCardName(card.getName());
        }

        getStyleClass().add(cardType);
        getStyleClass().add(colorStyle);

        // Top left: Name and Suit
        Label topLeft = new Label(name + "\n" + suit);
        topLeft.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        topLeft.setAlignment(Pos.TOP_LEFT);
        BorderPane.setAlignment(topLeft, Pos.TOP_LEFT);
        BorderPane.setMargin(topLeft, new Insets(6, 0, 0, 8));
        setTop(topLeft);

        // Center: Large Rank
        Label centerRank = new Label(rank);
        centerRank.setFont(Font.font("Arial", FontWeight.BOLD, 54));
        centerRank.setAlignment(Pos.CENTER);
        setCenter(centerRank);

        // Bottom right: Suit/Name mirrored
        Label bottomRight = new Label(suit + "\n" + name);
        bottomRight.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        bottomRight.setAlignment(Pos.BOTTOM_RIGHT);
        bottomRight.setRotate(180);
        BorderPane.setAlignment(bottomRight, Pos.BOTTOM_RIGHT);
        BorderPane.setMargin(bottomRight, new Insets(0, 8, 6, 0));
        setBottom(bottomRight);

        // Card border and background
        setStyle("-fx-background-color: white; -fx-border-color: #333; -fx-border-width: 2px; -fx-border-radius: 16px; -fx-background-radius: 16px;");
    }
    
    // Helper method to get a visual symbol for the card
    private String getCardSymbol(Card card) {
        if (card instanceof Wild) {
            if (card.getName().contains("BURNER")) {
                return "🔥"; // Fire symbol for burner
            } else if (card.getName().contains("SAVER")) {
                return "⭐"; // Star symbol for saver
            } else {
                return "⚡"; // Lightning for other wild cards
            }
        } else {
            String name = card.getName();
            if (name.contains("HEART")) {
                return "♥";
            } else if (name.contains("DIAMOND")) {
                return "♦";
            } else if (name.contains("SPADE")) {
                return "♠";
            } else if (name.contains("CLUB")) {
                return "♣";
            }
        }
        return "?";
    }
    
    // Helper method to format card name for display
    private String formatCardName(String fullName) {
        // Handle special cards
        if (fullName.contains("ACE")) {
            return "A";
        } else if (fullName.contains("KING")) {
            return "K";
        } else if (fullName.contains("QUEEN")) {
            return "Q";
        } else if (fullName.contains("JACK")) {
            return "J";
        } else if (fullName.contains("BURNER")) {
            return "B";
        } else if (fullName.contains("SAVER")) {
            return "S";
        } 
        
        // Handle number cards
        try {
            if (fullName.contains("10")) {
                return "10";
            }
            // Extract any digit if present
            for (int i = 2; i <= 9; i++) {
                if (fullName.contains(Integer.toString(i))) {
                    return Integer.toString(i);
                }
            }
        } catch (Exception e) {
            // In case of any parsing error
        }
        
        // Fallback
        return fullName.substring(0, Math.min(1, fullName.length()));
    }
    
    public Card getCard() {
        return card;
    }
    
    public void setSelected(boolean selected) {
        isSelected = selected;
        if (selected) {
            if (!getStyleClass().contains("card-selected")) {
                getStyleClass().add("card-selected");
            }
        } else {
            getStyleClass().remove("card-selected");
        }
    }
    
    public boolean isSelected() {
        return isSelected;
    }
    
    // Renamed from setScaleX to avoid overriding final method
    public void applyScaleX(double scale) {
        super.setScaleX(scale);
        updateFontSizes(scale);
    }
    
    // Renamed from setScaleY to avoid overriding final method
    public void applyScaleY(double scale) {
        super.setScaleY(scale);
        updateFontSizes(scale);
    }
    
    private void updateFontSizes(double scale) {
        // Scale font sizes relative to the overall scaling
        for (Object node : lookupAll("Label")) {
            if (node instanceof Label) {
                Label label = (Label) node;
                double originalSize = label.getFont().getSize();
                label.setFont(Font.font(label.getFont().getFamily(), originalSize * scale));
            }
        }
    }

    public void setCard(Card card) {
        this.card = card;
        System.out.println("[DEBUG] CardView.setCard: Setting card to " + (card != null ? card.getName() : "null"));
        updateDisplay();
    }

    public void updateDisplay() {
        getChildren().clear();
        getStyleClass().clear(); // Clear all style classes to prevent style issues
        getStyleClass().add("card"); // Re-add the basic card style
        
        System.out.println("[DEBUG] CardView.updateDisplay: Updating CardView for " + (card != null ? card.getName() : "null card"));
        
        if (card == null) {
            // Just display an empty card back
            setupTextBasedCard();
            return;
        }
        
        // Determine if this is a special card
        boolean isSpecialCard = false;
        if (card instanceof Wild) {
            isSpecialCard = true;
            if (card instanceof model.card.wild.Burner) {
                System.out.println("[DEBUG] CardView.updateDisplay: Updating a Burner card");
                getStyleClass().add("card-burner");
            } else if (card instanceof model.card.wild.Saver) {
                System.out.println("[DEBUG] CardView.updateDisplay: Updating a Saver card");
                getStyleClass().add("card-saver");
            }
        } else if (card instanceof model.card.standard.Standard) {
            // Add specific classes for standard cards by rank
            model.card.standard.Standard standardCard = (model.card.standard.Standard)card;
            int rank = standardCard.getRank();
            
            if (rank == 1) {
                getStyleClass().add("card-ace");
            } else if (rank == 11) {
                getStyleClass().add("card-jack");
            } else if (rank == 12) {
                getStyleClass().add("card-queen");
            } else if (rank == 13) {
                getStyleClass().add("card-king");
            }
            
            // Add color classes
            switch(standardCard.getSuit()) {
                case HEART:
                case DIAMOND:
                    getStyleClass().add("card-red");
                    break;
                case SPADE:
                case CLUB:
                    getStyleClass().add("card-black");
                    break;
            }
        }
        
        // Try to load and display the card image
        boolean imageLoaded = setupCardImage();
        
        if (!imageLoaded) {
            System.out.println("[DEBUG] CardView.updateDisplay: Falling back to text-based card for " + card.getName());
            setupTextBasedCard();
        } else {
            System.out.println("[DEBUG] CardView.updateDisplay: Successfully loaded image card for " + card.getName());
            
            // For special cards, add a label with their function
            if (isSpecialCard && cardImageView != null) {
                Label cardNameLabel = new Label();
                if (card instanceof model.card.wild.Burner) {
                    cardNameLabel.setText("Burner");
                } else if (card instanceof model.card.wild.Saver) {
                    cardNameLabel.setText("Saver");
                }
                cardNameLabel.setStyle(
                    "-fx-text-fill: white; " +
                    "-fx-background-color: rgba(0,0,0,0.7); " +
                    "-fx-padding: 3px 5px; " +
                    "-fx-background-radius: 5px; " +
                    "-fx-font-weight: bold;"
                );
                
                StackPane stackPane = (StackPane) getCenter();
                if (stackPane != null) {
                    stackPane.getChildren().add(cardNameLabel);
                    StackPane.setAlignment(cardNameLabel, javafx.geometry.Pos.BOTTOM_CENTER);
                    StackPane.setMargin(cardNameLabel, new javafx.geometry.Insets(0, 0, 10, 0));
                }
            }
        }
        
        // Make sure card is fully visible
        setOpacity(1.0);
        
        // Add enhanced visual effects based on card type
        if (isSpecialCard) {
            // Gold glow for special cards
            setStyle(getStyle() + "; -fx-effect: dropshadow(gaussian, rgba(255,215,0,0.7), 15, 0, 0, 0);");
        } else if (card instanceof model.card.standard.Standard) {
            // Subtle glow for standard cards
            model.card.standard.Standard standardCard = (model.card.standard.Standard)card;
            switch(standardCard.getSuit()) {
                case HEART:
                case DIAMOND:
                    setStyle(getStyle() + "; -fx-effect: dropshadow(gaussian, rgba(220,20,60,0.4), 8, 0, 0, 0);");
                    break;
                case SPADE:
                case CLUB:
                    setStyle(getStyle() + "; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.6), 8, 0, 0, 0);");
                    break;
            }
        }
        
        // Force a layout refresh
        requestLayout();
        playCardAnimation();
    }

    public void playCardAnimation() {
        ScaleTransition st = new ScaleTransition(Duration.millis(220), this);
        st.setFromX(1.0);
        st.setFromY(1.0);
        st.setToX(1.15);
        st.setToY(1.15);
        st.setAutoReverse(true);
        st.setCycleCount(2);
        st.play();
    }
} 