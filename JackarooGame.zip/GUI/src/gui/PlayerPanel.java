package gui;

import java.util.ArrayList;

import engine.Game;
import engine.GameManager;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.control.Button;
import javafx.scene.Node;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.Slider;
import model.Colour;
import model.card.Card;
import model.player.Player;
import engine.board.CellType;
import gui.CellView;
import model.player.*;
import javafx.animation.FadeTransition;
import javafx.util.Duration;

public class PlayerPanel extends BorderPane {
    
    private Player player;
    private GameScreen gameScreen;
    private Game gm;
    private ArrayList<CardView> cardViews = new ArrayList<>();
    private StackPane cardDisplayPane; // Single card display area
    private Slider cardSlider; // Slider for human player cards
    private boolean isHorizontal = true; // Default to horizontal layout
    private int currentCardIndex = 0;
    private Label marbleCountLabel;
    
    public PlayerPanel(Player player, GameScreen gameScreen, Game gm) {
        this.player = player;
        this.gameScreen = gameScreen;
        this.gm = gm;
        
        getStyleClass().add("player-panel");
        
        // Add player color as a style class
        String colorName = player.getColour().toString().toLowerCase();
        getStyleClass().add("player-" + colorName);
        
        setPadding(new Insets(1));
        setMinSize(0, 0); // Allow panel to be as small as needed
        
        // Set horizontal layout for side panels (left/right of fire pit)
        // Vertical layout would be better for top/bottom panels
        if (player.getColour() == Colour.BLUE || player.getColour() == Colour.RED) {
            isHorizontal = false; // Use vertical orientation for top panels
        } else {
            isHorizontal = true; // Use horizontal orientation for side panels
        }
        
        setupUI();
    }
    
    public void setOrientation(boolean horizontal) {
        this.isHorizontal = horizontal;
        setupUI();
    }
    
    private void setupUI() {
        getChildren().clear(); // Clear any existing children
        setMaxSize(USE_PREF_SIZE, USE_PREF_SIZE);
        
        // Get player's color for styling
        Color playerJavaFXColor = convertToJavaFXColor(player.getColour());
        
        // Create a dark styled background for the panel with Western theme
        setStyle("-fx-background-color: rgba(40,30,20,0.9); -fx-background-radius: 8px; -fx-border-color: " + 
                toRGBCode(playerJavaFXColor) + "; -fx-border-width: 2px; -fx-border-radius: 8px;");
        
        // Create a very compact layout
        VBox mainContainer = new VBox(2); // Minimal spacing
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setPadding(new Insets(3)); // Minimal padding
        
        // --- Add avatar image at the top ---
        javafx.scene.image.ImageView avatarView = new javafx.scene.image.ImageView();
        String imgPath = "";
        if (isHumanPlayer()) {
            imgPath = "player.png";
        } else if (player.getName().equalsIgnoreCase("CPU 1")) {
            imgPath = "cpu1.png";
        } else if (player.getName().equalsIgnoreCase("CPU 2")) {
            imgPath = "cpu2.png";
        } else if (player.getName().equalsIgnoreCase("CPU 3")) {
            imgPath = "cpu3.png";
        }
        if (!imgPath.isEmpty()) {
            javafx.scene.image.Image avatarImg = new javafx.scene.image.Image(getClass().getResourceAsStream(imgPath));
            avatarView.setImage(avatarImg);
            avatarView.setFitWidth(60);
            avatarView.setFitHeight(60);
            avatarView.setPreserveRatio(true);
            avatarView.setSmooth(true);
            avatarView.setClip(new javafx.scene.shape.Circle(30, 30, 30)); // Circular clip
            avatarView.setStyle("-fx-effect: dropshadow(gaussian, #000, 8, 0.4, 0, 2);");
            mainContainer.getChildren().add(avatarView);
        }
        // --- End avatar image ---
        
        // Create four tiny home zones in a horizontal row at the top
        HBox homeZonesRow = createHomeZonesRow();
        
        // Player name and color in header
        HBox headerBox = createHeaderBox();
        
        // Add a marble count label
        marbleCountLabel = new Label("Marbles: " + player.getMarbles().size());
        marbleCountLabel.setFont(Font.font("Arial", FontWeight.BOLD, 10)); // Small font
        marbleCountLabel.setTextFill(Color.WHITE);
        marbleCountLabel.setStyle("-fx-padding: 0 3px;");
        
        // Create card display area - different for CPU vs human
        VBox cardArea = createCardArea();
        
        // Add components to main container
        if (isHumanPlayer()) {
            mainContainer.getChildren().addAll(homeZonesRow, headerBox, marbleCountLabel, cardArea);
        } else {
            mainContainer.getChildren().addAll(homeZonesRow, headerBox, cardArea, marbleCountLabel);
        }
        
        setCenter(mainContainer);
        
        // Update the cards
        updateCards();
    }
    
    private HBox createHomeZonesRow() {
        // Create horizontal row for the tiny home zones
        HBox homeZonesRow = new HBox(1); // Minimal spacing
        homeZonesRow.setAlignment(Pos.CENTER);
        homeZonesRow.setPadding(new Insets(0)); // No padding
        
        // Get player color
        Color playerColor = convertToJavaFXColor(player.getColour());
        
        // Create 4 tiny home zones
        for (int i = 0; i < 4; i++) {
            // Create a tiny home zone circle
            Circle marbleSpot = new Circle(3); // Very small radius
            marbleSpot.setFill(playerColor);
            marbleSpot.setStroke(Color.BLACK);
            marbleSpot.setStrokeWidth(0.3); // Thinner stroke
            
            // Create container with Western theme background
            StackPane homeZone = new StackPane(marbleSpot);
            homeZone.setPrefSize(8, 8); // Extremely small size
            homeZone.setMinSize(8, 8);
            homeZone.setMaxSize(8, 8);
            homeZone.setStyle("-fx-background-color: #8B4513; -fx-border-color: #DAA520; -fx-border-width: 0.3px;");
            
            homeZonesRow.getChildren().add(homeZone);
        }
        
        return homeZonesRow;
    }
    
    private VBox createCardArea() {
        VBox cardArea = new VBox(1);
        cardArea.setAlignment(Pos.CENTER);
        
        if (isHumanPlayer()) {
            // For human player - create a card display with navigation buttons
            cardDisplayPane = new StackPane();
            cardDisplayPane.setPrefSize(35, 35); // Smaller size
            cardDisplayPane.setMinSize(35, 35);
            cardDisplayPane.setStyle("-fx-border-color: #8B4513; -fx-border-width: 1px; -fx-background-color: rgba(40,30,20,0.9);");
            
            // Create navigation buttons
            Button leftButton = new Button("<");
            Button rightButton = new Button(">");
            leftButton.setPrefWidth(24);
            rightButton.setPrefWidth(24);
            leftButton.setStyle("-fx-font-size: 14px; -fx-background-radius: 5px; -fx-background-color: #8B4513; -fx-text-fill: white;");
            rightButton.setStyle("-fx-font-size: 14px; -fx-background-radius: 5px; -fx-background-color: #8B4513; -fx-text-fill: white;");
            
            leftButton.setOnAction(e -> {
                if (currentCardIndex > 0) {
                    showCard(currentCardIndex - 1);
                }
            });
            rightButton.setOnAction(e -> {
                if (currentCardIndex < cardViews.size() - 1) {
                    showCard(currentCardIndex + 1);
                }
            });
            
            // Layout: HBox [<] [cardDisplayPane] [>]
            HBox navBox = new HBox(4, leftButton, cardDisplayPane, rightButton);
            navBox.setAlignment(Pos.CENTER);
            navBox.setPadding(new Insets(2));
            
            cardArea.getChildren().add(navBox);
        } else {
            // For CPU - just show card count
            Label cardCountLabel = new Label("");
            cardCountLabel.setFont(Font.font("Arial", FontWeight.BOLD, 10)); // Smaller font
            cardCountLabel.setTextFill(Color.WHITE);
            cardCountLabel.setAlignment(Pos.CENTER);
            
            StackPane countContainer = new StackPane(cardCountLabel);
            countContainer.setPrefSize(35, 20); // Smaller size
            countContainer.setStyle("-fx-border-color: #8B4513; -fx-border-width: 1px; -fx-background-color: rgba(40,30,20,0.9);");
            
            cardArea.getChildren().add(countContainer);
            
            // Store reference for updates
            cardDisplayPane = countContainer;
        }
        
        return cardArea;
    }
    
    private HBox createHeaderBox() {
        // Create name label with player name and CPU designation
        String displayName = player.getName();
        if (displayName.startsWith("CPU")) {
            // Format as "CPU #" with color
            int cpuNumber = Integer.parseInt(displayName.replaceAll("\\D+",""));
            displayName = "CPU " + cpuNumber;
        }
        
        Label nameLabel = new Label(displayName);
        nameLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14)); // Larger font for visibility
        nameLabel.setTextFill(javafx.scene.paint.Color.WHITE);
        nameLabel.setMaxWidth(Double.MAX_VALUE);
        nameLabel.setWrapText(true);
        nameLabel.setEllipsisString(null);
        nameLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-color: transparent; -fx-padding: 0 4px;");
        
        // Create color indicator
        String colorName = player.getColour().toString();
        Label colorLabel = new Label(colorName);
        colorLabel.setFont(Font.font("Arial", FontWeight.BOLD, 10)); // Smaller font
        colorLabel.setTextFill(javafx.scene.paint.Color.WHITE);
        
        // Apply color-specific styling
        Color playerColor = convertToJavaFXColor(player.getColour());
        String colorStyle = "-fx-background-color: " + toRGBCode(playerColor) + 
                         "; -fx-text-fill: white; -fx-padding: 1px 3px; -fx-background-radius: 2px;";
        colorLabel.setStyle(colorStyle);
        
        // Create container
        HBox headerBox = new HBox(3, nameLabel, colorLabel); // Reduced spacing
        headerBox.setAlignment(Pos.CENTER);
        headerBox.setPadding(new Insets(2)); // Minimal padding
        headerBox.setPrefHeight(20); // Shorter height
        headerBox.setStyle("-fx-background-color: rgba(60,60,60,1); -fx-background-radius: 3px;");
        
        return headerBox;
    }
    
    public void updateCards() {
        cardViews.clear();
        
        // Get player's cards
        ArrayList<Card> cards = player.getHand();
        
        if (isHumanPlayer()) {
            // Create card views but only show the current one
            double cardScale = 0.4; // Medium scale for single card
            
            for (Card card : cards) {
                // Create a CardView with the game screen reference for better context
                CardView cardView = new CardView(card, gameScreen);
                
                // Check if this is a special card and apply special styling
                if (card instanceof model.card.wild.Wild) {
                    if (card instanceof model.card.wild.Burner) {
                        cardView.getStyleClass().add("card-burner");
                        System.out.println("Added Burner card to player hand: " + card.getName());
                    } else if (card instanceof model.card.wild.Saver) {
                        cardView.getStyleClass().add("card-saver");
                        System.out.println("Added Saver card to player hand: " + card.getName());
                    }
                }
                
                // Apply scaling
                String scaleStyle = String.format("-fx-scale-x: %.2f; -fx-scale-y: %.2f;", cardScale, cardScale);
                cardView.setStyle(scaleStyle);
                
                // Size card appropriately
                cardView.setMaxSize(60, 80);
                cardView.setPrefSize(60, 80);
                
                // Add click handler
                cardView.setOnMouseClicked(e -> {
                    if (gm != null) {
                        for (CardView cv : cardViews) {
                            cv.setSelected(cv == cardView);
                        }
                        gameScreen.handleCardSelection(cardView);
                    }
                });
                
                cardViews.add(cardView);
            }
            
            // Display the current card
            showCard(Math.min(currentCardIndex, Math.max(0, cards.size() - 1)));
            
        } else {
            // For CPU players, just show the count
            Label countLabel = findLabelInContainer(cardDisplayPane);
            if (countLabel != null) {
                countLabel.setText(cards.size() + " Cards");
            }
        }
    }
    
    private Label findLabelInContainer(StackPane container) {
        for (Node node : container.getChildren()) {
            if (node instanceof Label) {
                return (Label) node;
            }
        }
        return null;
    }
    
    private void showCard(int index) {
        if (cardViews.isEmpty()) return;
        if (index < 0) index = 0;
        if (index >= cardViews.size()) index = cardViews.size() - 1;
        currentCardIndex = index;
        cardDisplayPane.getChildren().setAll(cardViews.get(index));
        // Update button states if needed (find parent HBox and update)
        if (isHumanPlayer() && cardDisplayPane.getParent() instanceof HBox) {
            HBox navBox = (HBox) cardDisplayPane.getParent();
            if (navBox.getChildren().size() == 3) {
                Button leftButton = (Button) navBox.getChildren().get(0);
                Button rightButton = (Button) navBox.getChildren().get(2);
                leftButton.setDisable(currentCardIndex == 0);
                rightButton.setDisable(currentCardIndex == cardViews.size() - 1);
            }
        }
    }
    
    public void setActive(boolean active) {
        if (active) {
            if (!getStyleClass().contains("active-player")) {
                getStyleClass().add("active-player");
                
                // Add glow effect when active
                setStyle(getStyle() + "; -fx-effect: dropshadow(gaussian, " + 
                       toRGBCode(convertToJavaFXColor(player.getColour())) + ", 10, 0.7, 0, 0);");
            }
        } else {
            getStyleClass().remove("active-player");
            
            // Remove glow effect when inactive
            Color playerJavaFXColor = convertToJavaFXColor(player.getColour());
            setStyle("-fx-background-color: rgba(40,40,40,0.9); -fx-background-radius: 5px; -fx-border-color: " + 
                    toRGBCode(playerJavaFXColor) + "; -fx-border-width: 2px; -fx-border-radius: 5px;");
        }
    }
    
    // Convert model.Colour to JavaFX Color
    private Color convertToJavaFXColor(Colour colour) {
        switch (colour) {
            case BLUE:   return Color.rgb(65, 105, 225);  // Royal blue
            case RED:    return Color.rgb(220, 20, 60);   // Crimson red
            case GREEN:  return Color.rgb(34, 139, 34);   // Forest green
            case YELLOW: return Color.rgb(255, 215, 0);   // Gold yellow
            default:     return Color.GRAY;
        }
    }
    
    // Convert JavaFX color to CSS RGB code
    private String toRGBCode(Color color) {
        return String.format("#%02X%02X%02X",
                (int) (color.getRed() * 255),
                (int) (color.getGreen() * 255),
                (int) (color.getBlue() * 255));
    }
    
    public boolean isHumanPlayer() {
        // Check if this is the human player (not a CPU)
        return !(player.getName().startsWith("CPU"));
    }
    
    public Player getPlayer() {
        return player;
    }
    
    public ArrayList<CardView> getCardViews() {
        return cardViews;
    }
    
    // Get the currently selected card (for human player)
    public CardView getCurrentCardView() {
        if (isHumanPlayer() && !cardViews.isEmpty() && currentCardIndex >= 0 && currentCardIndex < cardViews.size()) {
            return cardViews.get(currentCardIndex);
        }
        return null;
    }
    
    // Add a method to update the marble count visually 
    public void updateMarbleCount() {
        try {
            System.out.println("[DEBUG] PlayerPanel for " + player.getName() + " marble list: " + player.getMarbles());
            System.out.println("[DEBUG] PlayerPanel for " + player.getName() + " marble count: " + player.getMarbles().size());
            if (marbleCountLabel != null) {
                marbleCountLabel.setText("Marbles: " + player.getMarbles().size());
            }
            if (getCenter() instanceof VBox) {
                VBox mainContainer = (VBox)getCenter();
                if (!mainContainer.getChildren().isEmpty() && mainContainer.getChildren().get(0) instanceof HBox) {
                    HBox homeZonesRow = (HBox)mainContainer.getChildren().get(0);
                    int marblesInHome = player.getMarbles().size();
                    int index = 0;
                    for (Node node : homeZonesRow.getChildren()) {
                        if (index < 4) {
                            if (node instanceof StackPane) {
                                StackPane homeZone = (StackPane)node;
                                boolean hasMarble = index < marblesInHome;
                                for (Node innerNode : homeZone.getChildren()) {
                                    if (innerNode instanceof Circle) {
                                        Circle marbleCircle = (Circle)innerNode;
                                        marbleCircle.setVisible(hasMarble);
                                        break;
                                    }
                                }
                            }
                            index++;
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("[ERROR] Failed to update marble count: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Helper: check if a marble is in the player's own base cell
    private boolean isMarbleInPlayerBase(Marble marble) {
        // Find the base cell for this player
        for (CellView cellView : gameScreen.boardView.getCellViewMap().values()) {
            if (cellView.getCell().getCellType() == CellType.BASE) {
                // Check if this base cell belongs to the player
                if (cellView.getCell().toString().toUpperCase().contains(player.getColour().toString())) {
                    // Check if this marble is in this cell
                    if (cellView.getMarbleView() != null && cellView.getMarbleView().getMarble() == marble) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
} 