package gui;

import java.io.IOException;

import engine.Game;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Screen;
import javafx.scene.image.Image;
import javafx.animation.FadeTransition;
import javafx.util.Duration;

public class JackarooApp extends Application {
    private Game gameEngine;
    private Stage primaryStage;
    private Rectangle2D screenBounds;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        primaryStage.setTitle("Jackaroo Board Game");
        
        // Get screen dimensions for consistent use throughout the app
        screenBounds = Screen.getPrimary().getBounds();
        
        // Set the stage to be maximized and fill the screen
        primaryStage.setMaximized(true);
        primaryStage.setFullScreen(true);
        
        // Allow resize for responsive layouts
        primaryStage.setResizable(true);
        
        // Set minimum window size to prevent elements from being too compressed
        primaryStage.setMinWidth(screenBounds.getWidth() * 0.75);
        primaryStage.setMinHeight(screenBounds.getHeight() * 0.75);
        
        // Set the application icon
        primaryStage.getIcons().add(new Image(getClass().getResourceAsStream("/gui/logo.png")));
        
        showWelcomeScreen();
    }

    private void setSceneWithFade(Scene newScene) {
        if (primaryStage.getScene() != null && primaryStage.getScene().getRoot() != null) {
            FadeTransition fadeOut = new FadeTransition(Duration.millis(250), primaryStage.getScene().getRoot());
            fadeOut.setToValue(0);
            fadeOut.setOnFinished(e -> {
                primaryStage.setScene(newScene);
                FadeTransition fadeIn = new FadeTransition(Duration.millis(250), newScene.getRoot());
                newScene.getRoot().setOpacity(0);
                fadeIn.setToValue(1);
                fadeIn.play();
            });
            fadeOut.play();
        } else {
            primaryStage.setScene(newScene);
            newScene.getRoot().setOpacity(0);
            FadeTransition fadeIn = new FadeTransition(Duration.millis(250), newScene.getRoot());
            fadeIn.setToValue(1);
            fadeIn.play();
        }
    }

    public void showWelcomeScreen() {
        WelcomeScreen welcomeScreen = new WelcomeScreen(this);
        Scene scene = new Scene(welcomeScreen, screenBounds.getWidth(), screenBounds.getHeight());
        scene.getStylesheets().add(
            getClass().getResource("styles.css").toExternalForm()
        );
        setSceneWithFade(scene);
        primaryStage.setMaximized(true);
        Platform.runLater(() -> primaryStage.setFullScreen(true));
        primaryStage.show();
    }

    public void startGame(String playerName) {
        try {
            gameEngine = new Game(playerName);
            GameScreen gameScreen = new GameScreen(gameEngine, this);
            Scene scene = new Scene(gameScreen, screenBounds.getWidth(), screenBounds.getHeight());
            scene.getStylesheets().add(
                getClass().getResource("styles.css").toExternalForm()
            );
            setSceneWithFade(scene);
            primaryStage.setMaximized(true);
            Platform.runLater(() -> primaryStage.setFullScreen(true));
            
            // Resume background music when returning to game screen
            GameScreen.resumeBackgroundMusic();
        } catch (IOException e) {
            showError("Game Initialization Error",
                      "Could not start the game: " + e.getMessage());
        }
    }

    public void showGameStoryScreen() {
        GameStoryScreen storyScreen = new GameStoryScreen(this);
        Scene scene = new Scene(storyScreen, screenBounds.getWidth(), screenBounds.getHeight());
        scene.getStylesheets().add(
            getClass().getResource("styles.css").toExternalForm()
        );
        setSceneWithFade(scene);
        primaryStage.setMaximized(true);
        Platform.runLater(() -> primaryStage.setFullScreen(true));
        primaryStage.show();
    }

    public void showGameRulesScreen() {
        GameStoryScreen storyScreen = new GameStoryScreen(this);
        Scene scene = new Scene(storyScreen, screenBounds.getWidth(), screenBounds.getHeight());
        scene.getStylesheets().add(
            getClass().getResource("styles.css").toExternalForm()
        );
        primaryStage.setScene(scene);
        primaryStage.setMaximized(true);
        Platform.runLater(() -> primaryStage.setFullScreen(true));
        primaryStage.show();
    }

    /**
     * Custom error dialog using a small modal Stage.
     */
    public void showError(String title, String message) {
        Platform.runLater(() -> {
            Stage dialog = new Stage();
            dialog.initOwner(primaryStage);
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.setTitle(title);
            dialog.getIcons().add(new Image(getClass().getResourceAsStream("/gui/logo.png")));

            Text text = new Text(message);
            Button ok = new Button("OK");
            ok.setOnAction(e -> dialog.close());

            VBox root = new VBox(10, text, ok);
            root.setPadding(new Insets(20));
            root.setAlignment(Pos.CENTER);

            Scene scene = new Scene(root);
            scene.getStylesheets().add(
                getClass().getResource("styles.css").toExternalForm()
            );
            dialog.setScene(scene);
            dialog.showAndWait();
        });
    }

    public void showGameRules() {
        Platform.runLater(() -> {
            Stage rulesStage = new Stage();
            rulesStage.initOwner(primaryStage);
            rulesStage.initModality(Modality.APPLICATION_MODAL);
            rulesStage.setTitle("Jackaroo Game Rules");
            rulesStage.getIcons().add(new Image(getClass().getResourceAsStream("/gui/logo.png")));

            Text rulesTitle = new Text("Jackaroo Game Rules");
            rulesTitle.setStyle("-fx-font-size: 22px; -fx-font-weight: bold;");
            Text rulesText = new Text(
                "How to Play Jackaroo:\n\n" +
                "1. On your turn, select a card from your hand and play it to move your marbles.\n\n" +
                "2. Special cards have unique abilities:\n" +
                "   • Ace: Move a marble 1 space OR field a new marble from home.\n" +
                "   • King: Move a marble 13 spaces OR field a new marble from home.\n" +
                "   • Jack: Swap positions of your marble with an opponent's marble.\n" +
                "   • Seven: Split 7 steps between two of your marbles.\n" +
                "   • Burner (Wild): Destroy an opponent's marble (sending it back home).\n" +
                "   • Saver (Wild): Send one of your marbles to your safe zone.\n\n" +
                "3. To win, get all your marbles into your safe zone before the other players.\n\n" +
                "4. You can destroy opponent marbles by landing on them, sending them back home."
            );
            rulesText.setStyle("-fx-font-size: 15px;");
            Button closeButton = new Button("Close");
            closeButton.setOnAction(e -> rulesStage.close());

            VBox root = new VBox(20, rulesTitle, rulesText, closeButton);
            root.setPadding(new Insets(20));
            root.setAlignment(Pos.CENTER);

            Scene scene = new Scene(root, 600, 400);
            scene.getStylesheets().add(
                getClass().getResource("styles.css").toExternalForm()
            );
            rulesStage.setScene(scene);
            rulesStage.showAndWait();
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
