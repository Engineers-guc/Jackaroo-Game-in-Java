package gui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.Window;

/**
 * Custom error dialog that displays error messages in a popup window with an X button to close it.
 */
public class ErrorDialog {
    
    private Stage dialogStage;
    private VBox contentPane;
    
    /**
     * Create a new error dialog.
     * 
     * @param owner The owner window of this dialog
     * @param title The title of the dialog
     * @param message The error message to display
     */
    public ErrorDialog(Window owner, String title, String message) {
        // Create stage
        dialogStage = new Stage();
        dialogStage.initOwner(owner);
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.initStyle(StageStyle.UNDECORATED);
        dialogStage.setResizable(false);
        
        // Create the title bar with close button
        HBox titleBar = createTitleBar(title);
        
        // Create the message display
        VBox messageBox = createMessageBox(message);
        
        // Create the content pane
        contentPane = new VBox();
        contentPane.getChildren().addAll(titleBar, messageBox);
        contentPane.setStyle("-fx-background-color: #222; -fx-border-color: #444; -fx-border-width: 1px;");
        
        // Create scene
        Scene scene = new Scene(contentPane);
        dialogStage.setScene(scene);
        
        // Add CSS for styling
        scene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());
    }
    
    /**
     * Create the title bar with close button.
     */
    private HBox createTitleBar(String title) {
        HBox titleBar = new HBox();
        titleBar.setAlignment(Pos.CENTER_LEFT);
        titleBar.setPadding(new Insets(10, 10, 10, 15));
        titleBar.setStyle("-fx-background-color: #c62828;"); // Red background for error
        
        // Title text
        Text titleText = new Text(title);
        titleText.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        titleText.setFill(Color.WHITE);
        
        // Close button
        Button closeButton = new Button("✕");
        closeButton.setStyle("-fx-background-color: transparent; -fx-text-fill: white; -fx-font-weight: bold;");
        closeButton.setOnAction(e -> dialogStage.close());
        
        // Add components with spacing
        HBox.setHgrow(titleText, Priority.ALWAYS);
        titleBar.getChildren().addAll(titleText, closeButton);
        
        return titleBar;
    }
    
    /**
     * Create the message display box.
     */
    private VBox createMessageBox(String message) {
        VBox messageBox = new VBox();
        messageBox.setAlignment(Pos.CENTER_LEFT);
        messageBox.setPadding(new Insets(20));
        messageBox.setSpacing(15);
        
        // Error message
        Label messageLabel = new Label(message);
        messageLabel.setFont(Font.font("Arial", 14));
        messageLabel.setWrapText(true);
        messageLabel.setPrefWidth(350); // Set preferred width for wrapping
        messageLabel.setTextFill(Color.WHITE);
        
        // OK button to close
        Button okButton = new Button("OK");
        okButton.setPrefWidth(100);
        okButton.setStyle("-fx-background-color: #444; -fx-text-fill: white;");
        okButton.setOnAction(e -> dialogStage.close());
        
        // Container for OK button (centered)
        HBox buttonBox = new HBox(okButton);
        buttonBox.setAlignment(Pos.CENTER);
        
        messageBox.getChildren().addAll(messageLabel, buttonBox);
        return messageBox;
    }
    
    /**
     * Show the error dialog.
     */
    public void show() {
        dialogStage.show();
    }
    
    /**
     * Show the error dialog and wait for it to be closed.
     */
    public void showAndWait() {
        dialogStage.showAndWait();
    }
    
    /**
     * Static helper method to quickly show an error dialog.
     */
    public static void showError(Window owner, String title, String message) {
        ErrorDialog dialog = new ErrorDialog(owner, title, message);
        dialog.show();
    }
} 