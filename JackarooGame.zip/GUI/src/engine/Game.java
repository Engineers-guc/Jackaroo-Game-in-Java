package engine;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import engine.board.Board;
import engine.board.SafeZone;
import exception.CannotDiscardException;
import exception.CannotFieldException;
import exception.GameException;
import exception.IllegalDestroyException;
import exception.InvalidCardException;
import exception.InvalidMarbleException;
import exception.SplitOutOfRangeException;
import model.Colour;
import model.card.Card;
import model.card.Deck;
import model.player.*;

@SuppressWarnings("unused")
public class Game implements GameManager {
    private final Board board;
    private final ArrayList<Player> players;
	private int currentPlayerIndex;
    private final ArrayList<Card> firePit;
    private int turn;

    public Game(String playerName) throws IOException {
        turn = 0;
        currentPlayerIndex = 0;
        firePit = new ArrayList<>();

        ArrayList<Colour> colourOrder = new ArrayList<>();
        
        colourOrder.addAll(Arrays.asList(Colour.values()));
        
        Collections.shuffle(colourOrder);
        
        this.board = new Board(colourOrder, this);
        
        Deck.loadCardPool(this.board, (GameManager)this);
        
        this.players = new ArrayList<>();
        this.players.add(new Player(playerName, colourOrder.get(0)));
        
        for (int i = 1; i < 4; i++) 
            this.players.add(new CPU("CPU " + i, colourOrder.get(i), this.board));
        
        for (int i = 0; i < 4; i++) 
            this.players.get(i).setHand(Deck.drawCards());
        
    }
    
    public Board getBoard() {
        return board;
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    public ArrayList<Card> getFirePit() {
        return firePit;
    }
    
    public void selectCard(Card card) throws InvalidCardException {
        players.get(currentPlayerIndex).selectCard(card);
    }

    public void selectMarble(Marble marble) throws InvalidMarbleException {
        players.get(currentPlayerIndex).selectMarble(marble);
    }

    public void deselectAll() {
        players.get(currentPlayerIndex).deselectAll();
    }

    public void editSplitDistance(int splitDistance) throws SplitOutOfRangeException {
        if(splitDistance < 1 || splitDistance > 6)
            throw new SplitOutOfRangeException();

        board.setSplitDistance(splitDistance);
    }

    public boolean canPlayTurn() {
        return players.get(currentPlayerIndex).getHand().size() == (4 - turn);
    }

    public void playPlayerTurn() throws GameException {
        players.get(currentPlayerIndex).play();
    }

    public void endPlayerTurn() {
        Card selected = players.get(currentPlayerIndex).getSelectedCard();
        players.get(currentPlayerIndex).getHand().remove(selected);
        firePit.add(selected);
        players.get(currentPlayerIndex).deselectAll();
        
        currentPlayerIndex = (currentPlayerIndex + 1) % 4;
        
        if(currentPlayerIndex == 0 && turn < 3) 
            turn++;
        
        else if (currentPlayerIndex == 0 && turn == 3) {
        	turn = 0;
        	for (Player p : players) {
              if(Deck.getPoolSize() < 4) {
	              Deck.refillPool(firePit);
	              firePit.clear();
              }
              ArrayList<Card> newHand = Deck.drawCards();
              p.setHand(newHand);
        	}
        	
        	// Verify all players have exactly 4 cards after the round ends
        	verifyPlayerHandSizes();
        }
    }

    public Colour checkWin() {
        for(SafeZone safeZone : board.getSafeZones()) 
            if(safeZone.isFull())
                return safeZone.getColour();
    
        return null;
    }

    @Override
    public void sendHome(Marble marble) {
        for (Player player : players) {
            if (player.getColour() == marble.getColour()) {
                player.regainMarble(marble);
                break;
            }
        }
    }

    @Override
    public void fieldMarble() throws CannotFieldException, IllegalDestroyException {
        Marble marble = players.get(currentPlayerIndex).getOneMarble();
        
        if (marble == null)
        	throw new CannotFieldException("No marbles left in the Home Zone to field.");
        
        board.sendToBase(marble);
        players.get(currentPlayerIndex).getMarbles().remove(marble);
    }
    
    @Override
    public void discardCard(Colour colour) throws CannotDiscardException {
        for (Player player : players) {
            if (player.getColour() == colour) {
                int handSize = player.getHand().size();
                if(handSize == 0)
                    throw new CannotDiscardException("Player has no cards to discard.");
                int randIndex = (int) (Math.random() * handSize);
                this.firePit.add(player.getHand().remove(randIndex));
            }
        }
    }

    @Override
    public void discardCard() throws CannotDiscardException {
        int randIndex = (int) (Math.random() * 4);
        while(randIndex == currentPlayerIndex)
            randIndex = (int) (Math.random() * 4);

        discardCard(players.get(randIndex).getColour());
    }

    @Override
    public Colour getActivePlayerColour() {
        return players.get(currentPlayerIndex).getColour();
    }

    @Override
    public Colour getNextPlayerColour() {
        return players.get((currentPlayerIndex + 1) % 4).getColour();
    }

    public int getCurrentPlayerIndex() {
        return currentPlayerIndex;
    }

    public int getNextPlayerIndex() {
        return (currentPlayerIndex + 1) % players.size();
    }
    
    /**
     * Skips to the next player without discarding any cards
     * Used when a player chooses to skip their turn completely
     */
    public void skipToNextPlayer() {
        // Only advance the player, don't discard any cards
        currentPlayerIndex = (currentPlayerIndex + 1) % 4;
        
        // Handle round transitions
        if(currentPlayerIndex == 0 && turn < 3) 
            turn++;
        
        else if (currentPlayerIndex == 0 && turn == 3) {
            turn = 0;
            for (Player p : players) {
                if(Deck.getPoolSize() < 4) {
                    Deck.refillPool(firePit);
                    firePit.clear();
                }
                ArrayList<Card> newHand = Deck.drawCards();
                p.setHand(newHand);
            }
            
            // Verify all players have exactly 4 cards after the round ends
            verifyPlayerHandSizes();
        }
    }

    /**
     * Verifies that all players have exactly 4 cards in their hand
     * and adds cards if needed to ensure this condition is met
     */
    public void verifyPlayerHandSizes() {
        for (int i = 0; i < players.size(); i++) {
            Player player = players.get(i);
            int handSize = player.getHand().size();
            
            if (handSize < 4) {
                // If a player somehow has fewer than 4 cards, draw more cards for them
                System.out.println("Player " + player.getName() + " has only " + handSize + " cards. Drawing " + (4 - handSize) + " more.");
                
                // Make sure we have enough cards in the pool
                if (Deck.getPoolSize() < (4 - handSize)) {
                    Deck.refillPool(firePit);
                    firePit.clear();
                }
                
                // Draw the additional cards needed
                for (int j = handSize; j < 4; j++) {
                    ArrayList<Card> additionalCard = Deck.drawCards();
                    if (!additionalCard.isEmpty()) {
                        player.getHand().add(additionalCard.get(0));
                        // Add any extras back to the pool
                        for (int k = 1; k < additionalCard.size(); k++) {
                            ArrayList<Card> extras = new ArrayList<>();
                            extras.add(additionalCard.get(k));
                            Deck.refillPool(extras);
                        }
                    }
                }
            } else if (handSize > 4) {
                // If a player somehow has more than 4 cards, discard the excess
                System.out.println("Player " + player.getName() + " has " + handSize + " cards. Discarding " + (handSize - 4) + " excess cards.");
                for (int j = 0; j < handSize - 4; j++) {
                    Card excessCard = player.getHand().remove(handSize - 1 - j);
                    firePit.add(excessCard);
                }
            }
        }
    }

    /**
     * Checks if the given player is the current player
     * @param player The player to check
     * @return true if the player is the current player, false otherwise
     */
    public boolean isCurrentPlayerTurn(Player player) {
        if (player == null) return false;
        return player == players.get(currentPlayerIndex);
    }
}
