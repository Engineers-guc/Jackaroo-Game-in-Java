package model.card;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;

import engine.GameManager;
import engine.board.BoardManager;
import model.card.standard.Ace;
import model.card.standard.Five;
import model.card.standard.Four;
import model.card.standard.Jack;
import model.card.standard.King;
import model.card.standard.Queen;
import model.card.standard.Seven;
import model.card.standard.Standard;
import model.card.standard.Suit;
import model.card.standard.Ten;
import model.card.wild.Burner;
import model.card.wild.Saver;

public class Deck {
    private static final String CARDS_FILE = "Cards.csv";
    static private ArrayList<Card> cardsPool;

    @SuppressWarnings("resource")
	public static void loadCardPool(BoardManager boardManager, GameManager gameManager) throws IOException {
        cardsPool = new ArrayList<>();

		// Try several methods to load the Cards.csv resource
        BufferedReader br = null;
        IOException lastException = null;
        
        // Method 1: Try using class loader resource stream
        try {
            InputStream is = Deck.class.getClassLoader().getResourceAsStream(CARDS_FILE);
            if (is != null) {
                br = new BufferedReader(new InputStreamReader(is));
            }
        } catch (Exception e) {
            lastException = new IOException("Failed to load from classpath: " + e.getMessage(), e);
        }
        
        // Method 2: Try looking in resources directory
        if (br == null) {
            try {
                InputStream is = Deck.class.getClassLoader().getResourceAsStream("resources/" + CARDS_FILE);
                if (is != null) {
                    br = new BufferedReader(new InputStreamReader(is));
                }
            } catch (Exception e) {
                lastException = new IOException("Failed to load from resources directory: " + e.getMessage(), e);
            }
        }
        
        // Method 3: Try direct file access relative to working directory
        if (br == null) {
            File file = new File(CARDS_FILE);
            if (file.exists() && file.canRead()) {
                br = new BufferedReader(new FileReader(file));
            } else {
                File resourcesFile = new File("resources", CARDS_FILE);
                if (resourcesFile.exists() && resourcesFile.canRead()) {
                    br = new BufferedReader(new FileReader(resourcesFile));
                } else {
                    File guiResourcesFile = new File("GUI/resources", CARDS_FILE);
                    if (guiResourcesFile.exists() && guiResourcesFile.canRead()) {
                        br = new BufferedReader(new FileReader(guiResourcesFile));
                    }
                }
            }
        }
        
        // If still null, try the GUI/Cards.csv path
        if (br == null) {
            File guiFile = new File("GUI", CARDS_FILE);
            if (guiFile.exists() && guiFile.canRead()) {
                br = new BufferedReader(new FileReader(guiFile));
            }
        }
        
        // If all attempts failed, throw an exception
        if (br == null) {
            throw new IOException("Could not find Cards.csv file after trying multiple locations. " + 
                                 "Please ensure it is in the classpath or a resources directory.");
        }

		while (br.ready()) {
			String nextLine = br.readLine();
			String[] data = nextLine.split(",");
			
			if (data.length == 0) 
				throw new IOException(nextLine);

            String name = data[2];
            String description = data[3];
			
			int code = Integer.parseInt(data[0]);
			int frequency = Integer.parseInt(data[1]);
			
			for (int i = 0; i < frequency; i++) {
				Card card;
				
				if(code > 13) 
					switch(code) {
						case 14: card = new Burner(name, description, boardManager, gameManager); break;
						case 15: card = new Saver(name, description, boardManager, gameManager); break;
						default: throw new IOException(nextLine);
					}
			
				else {
	                int rank = Integer.parseInt(data[4]);
	                Suit cardSuit = Suit.valueOf(data[5]);
					switch(code) {
						case 0: card = new Standard(name, description, rank, cardSuit, boardManager, gameManager); break;
						case 1: card = new Ace(name, description, cardSuit, boardManager, gameManager); break;
						case 4: card = new Four(name, description, cardSuit, boardManager, gameManager); break;
						case 5: card = new Five(name, description, cardSuit, boardManager, gameManager); break;
						case 7: card = new Seven(name, description, cardSuit, boardManager, gameManager); break;
						case 10: card = new Ten(name, description, cardSuit, boardManager, gameManager); break;
						case 11: card = new Jack(name, description, cardSuit, boardManager, gameManager); break;
						case 12: card = new Queen(name, description, cardSuit, boardManager, gameManager); break;
						case 13: card = new King(name, description, cardSuit, boardManager, gameManager); break;
						default: throw new IOException(nextLine);
					}
				}
				
				cardsPool.add(card);
			}	
        }
    }

    public static ArrayList<Card> drawCards() {
        Collections.shuffle(cardsPool);
        ArrayList<Card> cards = new ArrayList<>(cardsPool.subList(0, 4));
        cardsPool.subList(0, 4).clear();
        return cards;
    }
    
    public static int getPoolSize() {
		return cardsPool.size();
	}

    public static void refillPool(ArrayList<Card> cards) {
        cardsPool.addAll(cards);
    }
}

